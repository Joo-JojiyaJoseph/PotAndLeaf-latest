<?php

namespace App\Http\Resources;

use App\Models\StockTransfer;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin StockTransfer */
class StockTransferResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $user = $request->user();
        $currentCompanyId = $request->attributes->get('company')?->id;
        $isSource = (string) $this->company_id === (string) $currentCompanyId;
        $isDest = $this->isIntraCompany()
            ? $isSource
            : (string) $this->to_company_id === (string) $currentCompanyId;
        $isHo = (bool) $user?->is_super_admin;
        $canAct = $isHo || $isSource || $isDest;
        $approveCompanyId = $isHo ? $this->company_id : $currentCompanyId;

        return [
            'id'              => $this->id,
            'company_id'      => $this->company_id,
            'transfer_no'     => $this->transfer_no,
            'transfer_date'   => optional($this->transfer_date)->toDateString(),
            'transfer_type'   => $this->transfer_type ?? 'inter_company',
            'from_company_id' => $this->company_id,
            'to_company_id'   => $this->to_company_id,
            'from_location_id'=> $this->from_location_id,
            'to_location_id'  => $this->to_location_id,
            'from_company'    => $this->fromCompany?->name,
            'to_company'      => $this->isIntraCompany()
                ? ($this->toLocation?->name ? "{$this->fromCompany?->name} (location move)" : $this->fromCompany?->name)
                : $this->toCompany?->name,
            'from_location'   => $this->fromLocation?->name ?? $this->fromCompany?->name,
            'to_location'     => $this->isIntraCompany()
                ? $this->toLocation?->name
                : ($this->toCompany?->name ?? $this->toLocation?->name),
            'status'          => $this->status,
            'approved_at'     => optional($this->approved_at)->toIso8601String(),
            'rejection_reason'=> $this->rejection_reason,
            'redirected_from_company_id' => $this->redirected_from_company_id,
            'redirected_from_company' => $this->redirectedFromCompany?->name,
            'redirected_at'   => optional($this->redirected_at)->toIso8601String(),
            'is_incoming'     => $isDest && ! $isSource,
            'is_intra_company'=> $this->isIntraCompany(),
            'notes'           => $this->notes,
            'dispatched_at'   => optional($this->dispatched_at)->toIso8601String(),
            'received_at'     => optional($this->received_at)->toIso8601String(),
            'items_count'     => $this->when($this->items_count !== null, $this->items_count),
            'items'           => $this->whenLoaded('items', fn () => $this->items->map(fn ($i) => [
                'id'               => $i->id,
                'product_id'       => $i->product_id,
                'product_name'     => $i->product_name,
                'qty'              => (float) $i->qty,
                'approved_qty'     => $i->approved_qty !== null ? (float) $i->approved_qty : null,
                'rejected_qty'     => (float) ($i->rejected_qty ?? 0),
                'rejection_reason' => $i->rejection_reason,
                'dispatch_qty'     => $i->dispatchQty(),
                'received_qty'     => (float) $i->received_qty,
                'batch_no'         => $i->batch?->batch_no,
                'barcode'          => $i->batch?->barcode,
                'source_purchase'  => $i->batch?->purchase?->purchase_no,
            ])->values()),
            'can'             => [
                'approve'  => $this->status === 'requested' && $canAct && $user?->hasPermission('transfers.approve', $approveCompanyId),
                'reject'   => $this->status === 'requested' && $canAct && $user?->hasPermission('transfers.approve', $approveCompanyId),
                'dispatch' => $this->status === 'draft' && ($isHo || $isSource) && $user?->hasPermission('transfers.dispatch', $this->company_id),
                'redirect' => $this->status === 'in_transit' && ! $this->isIntraCompany() && ($isHo || $isSource) && $user?->hasPermission('transfers.approve', $approveCompanyId),
                'receive'  => $this->status === 'in_transit' && ($isHo || $isDest) && $user?->hasPermission('transfers.receive', $isHo ? ($this->to_company_id ?? $this->company_id) : $currentCompanyId),
                'cancel'   => in_array($this->status, ['draft', 'in_transit', 'requested'], true) && ($isHo || $isSource) && $user?->hasPermission('transfers.delete', $this->company_id),
            ],
        ];
    }
}
