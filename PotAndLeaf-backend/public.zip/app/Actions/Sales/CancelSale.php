<?php

namespace App\Actions\Sales;

use App\Models\Customer;
use App\Models\Product;
use App\Models\Sale;
use App\Services\CommissionEngine;
use App\Services\InventoryService;
use App\Models\AdvanceOrder;
use App\Services\LoyaltyService;
use App\Services\PoolStockService;
use App\Services\ReceiptService;
use Illuminate\Support\Facades\DB;

class CancelSale
{
    public function __construct(
        private readonly InventoryService $inventory,
        private readonly LoyaltyService $loyalty,
        private readonly CommissionEngine $commissionEngine,
        private readonly ReceiptService $receipts,
        private readonly PoolStockService $pool,
    ) {}

    public function handle(Sale $sale, ?int $userId = null): Sale
    {
        return DB::transaction(function () use ($sale, $userId) {
            if ($sale->isConfirmed()) {
                $sale->loadMissing('items');

                foreach ($sale->items as $item) {
                    if (! $item->product_id) {
                        continue;
                    }
                    $product = Product::forCompany($sale->company_id)->lockForUpdate()->find($item->product_id);
                    if (! $product) {
                        continue;
                    }
                    // Pooled set/unit products were sold out of the shared
                    // unit pool, so they must go back through the pool too;
                    // posting on the set product directly left its derived
                    // stock wrong.
                    if ($this->pool->isPooled($product)) {
                        $this->pool->restore(
                            $product, (float) $item->qty, 'sale-cancel', $sale->id, "Reversal of {$sale->sale_no}", $userId,
                        );

                        continue;
                    }
                    $this->inventory->post(
                        product: $product, direction: 'in', qty: (float) $item->qty,
                        unitCost: (float) $product->cost_price, referenceType: 'sale-cancel',
                        referenceId: $sale->id, note: "Reversal of {$sale->sale_no}", userId: $userId,
                        productBatchId: $item->product_batch_id,
                    );
                    $product->save();
                    if ($item->product_batch_id) {
                        $batch = \App\Models\ProductBatch::where('id', $item->product_batch_id)->lockForUpdate()->first();
                        if ($batch) {
                            $batch->increment('remaining_qty', (float) $item->qty);
                            if ($batch->status === 'depleted') $batch->update(['status' => 'active']);
                        }
                    } else {
                        // Sold without a scanned batch (taken oldest-first): refill those batches.
                        $this->inventory->restoreBatchesFifo($product->id, (float) $item->qty);
                    }
                }

                if ($sale->customer_id) {
                    $customer = Customer::forCompany($sale->company_id)->lockForUpdate()->find($sale->customer_id);
                    if ($customer) {
                        $due = max(0, (float) $sale->grand_total - (float) $sale->loyalty_discount);
                        if ($sale->payment_mode === 'credit') {
                            $customer->outstanding = (float) $customer->outstanding - ($due - (float) $sale->amount_paid);
                            $customer->save();
                        }
                        $this->loyalty->reverseForSale($customer, $sale);
                    }
                }

                $this->receipts->voidForSale($sale);
                $this->commissionEngine->reverseOnSaleCancel($sale);
            }

            // A cancelled sale made from a booking re-opens the booking, so it
            // can be fulfilled again or cancelled (which refunds its advance).
            AdvanceOrder::query()
                ->where('company_id', $sale->company_id)
                ->where('sale_id', $sale->id)
                ->where('status', 'fulfilled')
                ->update(['status' => 'booked', 'sale_id' => null]);

            $sale->update([
                'status'                   => 'cancelled',
                'cancel_requested_at'      => null,
                'cancel_reason'            => null,
                'cancel_requested_by'      => null,
                'cancel_rejection_reason'  => null,
            ]);

            return $sale->refresh();
        });
    }
}
