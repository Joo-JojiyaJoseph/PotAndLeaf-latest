<?php

namespace App\Services;

use App\Models\CommissionTransaction;
use App\Models\Purchase;
use App\Models\PurchaseItem;
use App\Models\PurchaseReturn;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\SalesReturn;
use App\Models\SupervisorCommissionEntry;
use App\Models\User;
use Illuminate\Support\Carbon;

/** Sales comparison, YTD, trends, GST, commission reports, and leaderboards. */
class SalesAnalyticsService
{
    public function __construct(private readonly SettingsService $settings) {}

    public function financialYearStart(int|string|null $companyId, ?Carbon $asOf = null): Carbon
    {
        $asOf ??= now();
        // All companies (null) share the default April start.
        $startMonth = max(1, min(12, ($companyId !== null ? $this->settings->getInt($companyId, 'financial_year_start_month') : 0) ?: 4));
        $fyStart = $asOf->copy()->month >= $startMonth
            ? Carbon::create($asOf->year, $startMonth, 1)
            : Carbon::create($asOf->year - 1, $startMonth, 1);

        return $fyStart->startOfDay();
    }

    /** Detailed sales metrics for a date range. */
    public function salesMetrics(int|string|null $companyId, string $from, string $to, ?string $locationId = null): array
    {
        $from = Carbon::parse($from)->toDateString();
        $to = Carbon::parse($to)->toDateString();

        $salesQ = Sale::query()
            ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->where('status', 'confirmed')
            ->whereNotIn('bill_kind', ['proforma'])
            ->whereDate('sale_date', '>=', $from)
            ->whereDate('sale_date', '<=', $to)
            ->when($locationId, fn ($q) => $q->where('location_id', $locationId));

        $eligible = (clone $salesQ)->where('bill_kind', '!=', 'complimentary');

        $gross = round((float) (clone $salesQ)->sum('grand_total'), 2);
        $net = round((float) (clone $eligible)->selectRaw('SUM(subtotal - loyalty_discount) as n')->value('n'), 2);
        $tax = round((float) (clone $salesQ)->sum('tax_total'), 2);
        $loyaltyDiscount = round((float) (clone $eligible)->sum('loyalty_discount'), 2);

        $lineDiscount = round((float) SaleItem::query()
            ->whereHas('sale', fn ($q) => $q->when($companyId !== null, fn ($sq) => $sq->forCompany($companyId))
                ->where('status', 'confirmed')->whereDate('sale_date', '>=', $from)->whereDate('sale_date', '<=', $to)
                ->when($locationId, fn ($qq) => $qq->where('location_id', $locationId)))
            ->sum('discount'), 2);

        $returns = round((float) SalesReturn::query()
            ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->where('status', 'confirmed')
            ->whereDate('return_date', '>=', $from)
            ->whereDate('return_date', '<=', $to)
            ->when($locationId, fn ($q) => $q->whereHas('sale', fn ($sq) => $sq->where('location_id', $locationId)))
            ->sum('subtotal'), 2);

        $qty = round((float) SaleItem::query()
            ->whereHas('sale', fn ($q) => $q->when($companyId !== null, fn ($sq) => $sq->forCompany($companyId))
                ->where('status', 'confirmed')->whereDate('sale_date', '>=', $from)->whereDate('sale_date', '<=', $to)
                ->when($locationId, fn ($qq) => $qq->where('location_id', $locationId)))
            ->sum('qty'), 3);

        return [
            'from'              => $from,
            'to'                => $to,
            'location_id'       => $locationId,
            'gross_sales'       => $gross,
            'net_sales'         => max(0, round($net - $returns, 2)),
            'subtotal_net'      => $net,
            'returns'           => $returns,
            'discounts'         => round($loyaltyDiscount + $lineDiscount, 2),
            'loyalty_discount'  => $loyaltyDiscount,
            'line_discount'     => $lineDiscount,
            'tax'               => $tax,
            'invoice_count'     => (clone $salesQ)->count(),
            'customer_count'    => (clone $salesQ)->whereNotNull('customer_id')->distinct('customer_id')->count('customer_id'),
            'quantity_sold'     => $qty,
        ];
    }

    /** Current calendar month vs previous calendar month. */
    public function monthComparison(int|string|null $companyId, ?string $asOf = null, ?string $locationId = null): array
    {
        $asOf = Carbon::parse($asOf ?? now());
        $curFrom = $asOf->copy()->startOfMonth()->toDateString();
        $curTo = $asOf->toDateString();
        $prevFrom = $asOf->copy()->subMonth()->startOfMonth()->toDateString();
        $prevTo = $asOf->copy()->subMonth()->endOfMonth()->toDateString();

        $current = $this->salesMetrics($companyId, $curFrom, $curTo, $locationId);
        $previous = $this->salesMetrics($companyId, $prevFrom, $prevTo, $locationId);

        return $this->comparisonPayload('month', $current, $previous, [
            'current_period'  => ['from' => $curFrom, 'to' => $curTo],
            'previous_period' => ['from' => $prevFrom, 'to' => $prevTo],
            'by_day'          => $this->dailyComparison($companyId, $curFrom, $curTo, $prevFrom, $prevTo, $locationId),
        ]);
    }

    /** Same period year-over-year (defaults to current calendar month). */
    public function yearOnYear(int|string|null $companyId, ?string $month = null, ?string $locationId = null): array
    {
        $ref = $month ? Carbon::parse($month.'-01') : now();
        $curFrom = $ref->copy()->startOfMonth()->toDateString();
        $curTo = $ref->copy()->endOfMonth()->toDateString();
        $prevFrom = $ref->copy()->subYear()->startOfMonth()->toDateString();
        $prevTo = $ref->copy()->subYear()->endOfMonth()->toDateString();

        $current = $this->salesMetrics($companyId, $curFrom, $curTo, $locationId);
        $previous = $this->salesMetrics($companyId, $prevFrom, $prevTo, $locationId);

        return $this->comparisonPayload('yoy', $current, $previous, [
            'current_label'  => $ref->format('M Y'),
            'previous_label' => $ref->copy()->subYear()->format('M Y'),
        ]);
    }

    /** Financial year-to-date with prior-year YTD comparison. */
    public function yearToDate(int|string|null $companyId, ?string $asOf = null, ?string $locationId = null): array
    {
        $asOf = Carbon::parse($asOf ?? now());
        $fyStart = $this->financialYearStart($companyId, $asOf);
        $from = $fyStart->toDateString();
        $to = $asOf->toDateString();

        $daysElapsed = $fyStart->diffInDays($asOf) + 1;
        $priorFyStart = $fyStart->copy()->subYear();
        $priorTo = $priorFyStart->copy()->addDays($daysElapsed - 1);

        $current = $this->salesMetrics($companyId, $from, $to, $locationId);
        $previous = $this->salesMetrics($companyId, $priorFyStart->toDateString(), $priorTo->toDateString(), $locationId);

        $monthly = [];
        $cursor = $fyStart->copy()->startOfMonth();
        while ($cursor->lte($asOf)) {
            $mFrom = $cursor->copy()->startOfMonth()->toDateString();
            $mTo = $cursor->copy()->endOfMonth()->min($asOf)->toDateString();
            $monthly[] = array_merge(
                ['month' => $cursor->format('Y-m'), 'label' => $cursor->format('M Y')],
                $this->salesMetrics($companyId, $mFrom, $mTo, $locationId),
            );
            $cursor->addMonth();
        }

        return array_merge($this->comparisonPayload('ytd', $current, $previous, [
            'financial_year_start' => $from,
            'as_of'                => $to,
            'fy_start_month'       => (int) (($companyId !== null ? $this->settings->getInt($companyId, 'financial_year_start_month') : 0) ?: 4),
        ]), ['monthly_breakdown' => $monthly]);
    }

    /** Rolling 12 calendar months ending on reference date. */
    public function twelveMonthTrend(int|string|null $companyId, ?string $asOf = null, ?string $locationId = null): array
    {
        $asOf = Carbon::parse($asOf ?? now())->startOfMonth();
        $months = [];

        $prevNet = null;
        for ($i = 11; $i >= 0; $i--) {
            $m = $asOf->copy()->subMonths($i);
            $mFrom = $m->copy()->startOfMonth()->toDateString();
            $mTo = $m->copy()->endOfMonth()->toDateString();
            $metrics = $this->salesMetrics($companyId, $mFrom, $mTo, $locationId);
            $growthPct = ($prevNet !== null && $prevNet > 0)
                ? round(($metrics['net_sales'] - $prevNet) / $prevNet * 100, 2)
                : null;
            $prevNet = $metrics['net_sales'];

            $months[] = array_merge($metrics, [
                'month'      => $m->format('Y-m'),
                'label'      => $m->format('M Y'),
                'growth_pct' => $growthPct,
            ]);
        }

        return ['months' => $months, 'location_id' => $locationId];
    }

    /** Output vs input GST summary with drill-down lines. */
    public function gstReconciliation(int|string|null $companyId, string $from, string $to, ?string $locationId = null): array
    {
        $from = Carbon::parse($from)->toDateString();
        $to = Carbon::parse($to)->toDateString();

        $sales = Sale::query()
            ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->where('status', 'confirmed')
            ->whereNotIn('bill_kind', ['proforma', 'complimentary'])
            ->whereDate('sale_date', '>=', $from)
            ->whereDate('sale_date', '<=', $to)
            ->when($locationId, fn ($q) => $q->where('location_id', $locationId))
            ->get(['id', 'sale_no', 'sale_date', 'subtotal', 'tax_total', 'is_interstate']);

        $outputTax = round((float) $sales->sum('tax_total'), 2);
        $outputTaxable = round((float) $sales->sum('subtotal'), 2);

        $itemTax = SaleItem::query()
            ->whereIn('sale_id', $sales->pluck('id'))
            ->selectRaw('SUM(cgst_amount) as cgst, SUM(sgst_amount) as sgst, SUM(igst_amount) as igst, SUM(taxable_value) as taxable')
            ->first();

        $returnTax = round((float) SalesReturn::query()
            ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->where('status', 'confirmed')
            ->whereDate('return_date', '>=', $from)
            ->whereDate('return_date', '<=', $to)
            ->when($locationId, fn ($q) => $q->whereHas('sale', fn ($sq) => $sq->where('location_id', $locationId)))
            ->sum('tax_total'), 2);

        $purchases = Purchase::query()
            ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->where('status', 'confirmed')
            ->whereDate('purchase_date', '>=', $from)
            ->whereDate('purchase_date', '<=', $to)
            ->when($locationId, fn ($q) => $q->where('location_id', $locationId))
            ->get(['id', 'purchase_no', 'purchase_date', 'subtotal', 'tax_total']);

        $inputTax = round((float) $purchases->sum('tax_total'), 2);
        $inputTaxable = round((float) $purchases->sum('subtotal'), 2);

        $purchaseItemTax = PurchaseItem::query()
            ->whereIn('purchase_id', $purchases->pluck('id'))
            ->selectRaw('SUM(cgst_amount) as cgst, SUM(sgst_amount) as sgst, SUM(igst_amount) as igst')
            ->first();

        // GST on goods sent back to suppliers is input credit given back, so
        // it reduces the input tax claimed for the period.
        $purchaseReturnTax = round((float) PurchaseReturn::query()
            ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->where('status', 'confirmed')
            ->whereDate('return_date', '>=', $from)
            ->whereDate('return_date', '<=', $to)
            ->when($locationId, fn ($q) => $q->whereHas('purchase', fn ($pq) => $pq->where('location_id', $locationId)))
            ->sum('tax_total'), 2);

        $netPayable = round($outputTax - $returnTax - ($inputTax - $purchaseReturnTax), 2);

        return [
            'from' => $from,
            'to'   => $to,
            'location_id' => $locationId,
            'output' => [
                'taxable'    => $outputTaxable,
                'tax_total'  => $outputTax,
                'cgst'       => round((float) ($itemTax->cgst ?? 0), 2),
                'sgst'       => round((float) ($itemTax->sgst ?? 0), 2),
                'igst'       => round((float) ($itemTax->igst ?? 0), 2),
                'invoice_count' => $sales->count(),
            ],
            'sales_returns' => ['tax' => $returnTax],
            'purchase_returns' => ['tax' => $purchaseReturnTax],
            'input' => [
                'taxable'   => $inputTaxable,
                'tax_total' => $inputTax,
                'cgst'      => round((float) ($purchaseItemTax->cgst ?? 0), 2),
                'sgst'      => round((float) ($purchaseItemTax->sgst ?? 0), 2),
                'igst'      => round((float) ($purchaseItemTax->igst ?? 0), 2),
                'bill_count' => $purchases->count(),
            ],
            'net_gst_payable' => $netPayable,
            'sales_lines' => $sales->take(100)->map(fn ($s) => [
                'id' => $s->id, 'no' => $s->sale_no, 'date' => $s->sale_date->toDateString(),
                'taxable' => (float) $s->subtotal, 'tax' => (float) $s->tax_total,
            ])->values()->all(),
            'purchase_lines' => $purchases->take(100)->map(fn ($p) => [
                'id' => $p->id, 'no' => $p->purchase_no, 'date' => $p->purchase_date->toDateString(),
                'taxable' => (float) $p->subtotal, 'tax' => (float) $p->tax_total,
            ])->values()->all(),
        ];
    }

    /** Commission & incentive report for all staff types. */
    public function commissionReport(int|string|null $companyId, string $from, string $to, ?int $userId = null): array
    {
        $from = Carbon::parse($from)->toDateString();
        $to = Carbon::parse($to)->toDateString();

        $txQ = CommissionTransaction::query()->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->whereDate('transaction_date', '>=', $from)
            ->whereDate('transaction_date', '<=', $to)
            ->when($userId, fn ($q) => $q->where('user_id', $userId))
            ->with('user:id,name');

        $byUser = $txQ->get()->groupBy('user_id')->map(function ($rows, $uid) use ($companyId, $from, $to) {
            $user = $rows->first()->user;
            $salesForUser = (float) Sale::query()->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
                ->where('created_by', $uid)->where('status', 'confirmed')
                ->whereDate('sale_date', '>=', $from)->whereDate('sale_date', '<=', $to)
                ->selectRaw('SUM(subtotal - loyalty_discount) as n')->value('n');

            return [
                'user_id'           => (int) $uid,
                'user_name'         => $user?->name,
                'staff_type'        => $this->roleLabelsForUsers($companyId, [(int) $uid])[(int) $uid] ?? '—',
                'sales_net'         => round($salesForUser, 2),
                'salesman_tier'     => round((float) $rows->where('commission_type', 'salesman_tier')->whereIn('status', CommissionTransaction::COUNTED_STATUSES)->sum('amount'), 2),
                'daily_target'      => round((float) $rows->where('commission_type', 'daily_target')->whereIn('status', CommissionTransaction::COUNTED_STATUSES)->sum('amount'), 2),
                'promotion'         => round((float) $rows->where('commission_type', 'promotion')->whereIn('status', CommissionTransaction::COUNTED_STATUSES)->sum('amount'), 2),
                'manager'           => round((float) $rows->where('commission_type', 'manager')->whereIn('status', CommissionTransaction::COUNTED_STATUSES)->sum('amount'), 2),
                'reversals'         => round((float) $rows->where('commission_type', 'reversal')->sum('amount'), 2),
                'total_ledger'      => round((float) $rows->whereIn('status', CommissionTransaction::COUNTED_STATUSES)->sum('amount'), 2),
            ];
        })->values();

        $supervisor = SupervisorCommissionEntry::query()->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->whereDate('accrued_date', '>=', $from)
            ->whereDate('accrued_date', '<=', $to)
            ->when($userId, fn ($q) => $q->where('user_id', $userId))
            ->with('user:id,name')
            ->get()
            ->groupBy('user_id')
            ->map(fn ($rows, $uid) => [
                'user_id'   => (int) $uid,
                'user_name' => $rows->first()->user?->name,
                'supervisor_commission' => round((float) $rows->whereIn('status', SupervisorCommissionEntry::COUNTED_STATUSES)->sum('amount'), 2),
            ])->values();

        return [
            'from'       => $from,
            'to'         => $to,
            'staff'      => $byUser,
            'supervisor' => $supervisor,
            'totals'     => [
                'commission'  => round((float) $byUser->sum('total_ledger'), 2),
                'supervisor'  => round((float) $supervisor->sum('supervisor_commission'), 2),
            ],
        ];
    }

    /** Monthly or yearly staff leaderboard. Default rank metric is net sales (existing). */
    public function leaderboard(int|string|null $companyId, string $period = 'month', ?string $asOf = null, ?string $locationId = null, string $metric = 'net_sales'): array
    {
        $asOf = Carbon::parse($asOf ?? now());

        if ($period === 'year') {
            $from = $this->financialYearStart($companyId, $asOf)->toDateString();
            $to = $asOf->toDateString();
            $label = 'FY '.$this->financialYearStart($companyId, $asOf)->format('Y').'–'.$asOf->format('Y');
        } else {
            $from = $asOf->copy()->startOfMonth()->toDateString();
            $to = $asOf->copy()->endOfMonth()->toDateString();
            $label = $asOf->format('M Y');
        }

        $rows = Sale::query()
            ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->where('status', 'confirmed')
            ->whereNotIn('bill_kind', ['proforma', 'complimentary'])
            ->whereDate('sale_date', '>=', $from)
            ->whereDate('sale_date', '<=', $to)
            ->when($locationId, fn ($q) => $q->where('location_id', $locationId))
            ->whereNotNull('created_by')
            ->selectRaw('created_by as user_id, SUM(subtotal - loyalty_discount) as net_sales, COUNT(*) as invoices, SUM(1) as dummy')
            ->groupBy('created_by')
            ->orderByDesc('net_sales')
            ->get();

        $users = User::whereIn('id', $rows->pluck('user_id'))->get(['id', 'name'])->keyBy('id');
        $roleLabels = $this->roleLabelsForUsers($companyId, $rows->pluck('user_id')->map(fn ($id) => (int) $id)->all());
        $metric = in_array($metric, ['net_sales', 'invoices', 'incentives'], true) ? $metric : 'net_sales';

        $ranked = $rows->values()->map(function ($r) use ($users, $companyId, $from, $to, $roleLabels) {
            $net = round((float) $r->net_sales, 2);
            $commission = round((float) CommissionTransaction::query()
                ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
                ->where('user_id', $r->user_id)
                ->whereDate('transaction_date', '>=', $from)
                ->whereDate('transaction_date', '<=', $to)
                ->counted()
                ->sum('amount'), 2);

            return [
                'user_id'     => (int) $r->user_id,
                'user_name'   => $users[$r->user_id]->name ?? 'Staff #'.$r->user_id,
                'staff_type'  => $roleLabels[(int) $r->user_id] ?? '—',
                'net_sales'   => $net,
                'invoices'    => (int) $r->invoices,
                'incentives'  => $commission,
            ];
        });

        $ranked = $ranked->sortByDesc(function ($row) use ($metric) {
            return $row[$metric] ?? $row['net_sales'];
        })->values();

        $prev = null;
        $rank = 0;
        $display = $ranked->map(function ($row) use (&$prev, &$rank, $metric) {
            $score = (float) ($row[$metric] ?? $row['net_sales']);
            if ($prev === null || abs($score - $prev) > 0.01) {
                $rank++;
            }
            $row['rank'] = $rank;
            $row['score'] = $score;
            $row['metric'] = $metric;
            $prev = $score;

            return $row;
        });

        return [
            'period'      => $period,
            'label'       => $label,
            'from'        => $from,
            'to'          => $to,
            'location_id' => $locationId,
            'metric'      => $metric,
            'rankings'    => $display->values()->all(),
        ];
    }

    /** Day-of-month alignment of current vs previous period (gross, invoices, net). */
    private function dailyComparison(
        int|string|null $companyId,
        string $curFrom,
        string $curTo,
        string $prevFrom,
        string $prevTo,
        ?string $locationId,
    ): array {
        $current = $this->dailySalesByDate($companyId, $curFrom, $curTo, $locationId);
        $previous = $this->dailySalesByDate($companyId, $prevFrom, $prevTo, $locationId);
        $maxDay = max(
            Carbon::parse($curTo)->day,
            Carbon::parse($prevTo)->day,
        );

        $rows = [];
        $curStart = Carbon::parse($curFrom)->startOfMonth();
        $prevStart = Carbon::parse($prevFrom)->startOfMonth();
        $curEnd = Carbon::parse($curTo);
        $prevEnd = Carbon::parse($prevTo);
        for ($day = 1; $day <= $maxDay; $day++) {
            $curDate = $curStart->copy()->addDays($day - 1);
            $prevDate = $prevStart->copy()->addDays($day - 1);
            $curKey = ($curDate->month === $curStart->month && $curDate->lte($curEnd)) ? $curDate->toDateString() : null;
            $prevKey = ($prevDate->month === $prevStart->month && $prevDate->lte($prevEnd)) ? $prevDate->toDateString() : null;
            $cur = $curKey ? ($current[$curKey] ?? ['net_sales' => 0, 'invoice_count' => 0, 'gross_sales' => 0]) : ['net_sales' => 0, 'invoice_count' => 0, 'gross_sales' => 0];
            $prev = $prevKey ? ($previous[$prevKey] ?? ['net_sales' => 0, 'invoice_count' => 0, 'gross_sales' => 0]) : ['net_sales' => 0, 'invoice_count' => 0, 'gross_sales' => 0];
            $rows[] = [
                'day'               => $day,
                'current_date'      => $curKey,
                'previous_date'     => $prevKey,
                'current_net'       => $cur['net_sales'],
                'previous_net'      => $prev['net_sales'],
                'current_invoices'  => $cur['invoice_count'],
                'previous_invoices' => $prev['invoice_count'],
            ];
        }

        return $rows;
    }

    /** @return array<string, array{net_sales: float, invoice_count: int, gross_sales: float}> */
    private function dailySalesByDate(int|string|null $companyId, string $from, string $to, ?string $locationId): array
    {
        $rows = Sale::query()
            ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->where('status', 'confirmed')
            ->whereNotIn('bill_kind', ['proforma'])
            ->whereDate('sale_date', '>=', $from)
            ->whereDate('sale_date', '<=', $to)
            ->when($locationId, fn ($q) => $q->where('location_id', $locationId))
            ->selectRaw("DATE(sale_date) as d, SUM(grand_total) as gross, COUNT(*) as invoices, SUM(CASE WHEN bill_kind = 'complimentary' THEN 0 ELSE subtotal - loyalty_discount END) as net")
            ->groupByRaw('DATE(sale_date)')
            ->get();

        $out = [];
        foreach ($rows as $r) {
            $out[(string) $r->d] = [
                'gross_sales'   => round((float) $r->gross, 2),
                'net_sales'     => round((float) $r->net, 2),
                'invoice_count' => (int) $r->invoices,
            ];
        }

        return $out;
    }

    /** Company-scoped role names — the application's staff types. */
    private function roleLabelsForUsers(int|string|null $companyId, array $userIds): array
    {
        $userIds = array_values(array_unique(array_filter($userIds)));
        if ($userIds === []) {
            return [];
        }

        $rows = \Illuminate\Support\Facades\DB::table('role_user')
            ->join('roles', 'roles.id', '=', 'role_user.role_id')
            ->whereIn('role_user.user_id', $userIds)
            ->when($companyId !== null, fn ($q) => $q->where('role_user.company_id', $companyId))
            ->whereNull('roles.deleted_at')
            ->get(['role_user.user_id', 'roles.name']);

        return $rows->groupBy('user_id')->map(
            fn ($group) => $group->pluck('name')->unique()->filter()->implode(', ') ?: '—'
        )->all();
    }

    private function comparisonPayload(string $type, array $current, array $previous, array $meta = []): array
    {
        $curNet = (float) ($current['net_sales'] ?? 0);
        $prevNet = (float) ($previous['net_sales'] ?? 0);
        $diff = round($curNet - $prevNet, 2);
        $pct = $prevNet > 0 ? round($diff / $prevNet * 100, 2) : ($curNet > 0 ? 100.0 : 0.0);

        return array_merge($meta, [
            'comparison_type' => $type,
            'current'         => $current,
            'previous'        => $previous,
            'difference'      => [
                'net_sales' => $diff,
                'growth_pct'=> $pct,
                'invoices'  => ($current['invoice_count'] ?? 0) - ($previous['invoice_count'] ?? 0),
                'customers' => ($current['customer_count'] ?? 0) - ($previous['customer_count'] ?? 0),
            ],
        ]);
    }
}
