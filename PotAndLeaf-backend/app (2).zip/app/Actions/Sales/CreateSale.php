<?php

namespace App\Actions\Sales;

use App\Models\Customer;
use App\Models\Product;
use App\Models\Sale;
use App\Repositories\Contracts\SaleRepositoryInterface;
use App\Services\LoyaltyService;
use App\Services\SettingsService;
use App\Support\Sales\SaleCalculator;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CreateSale
{
    public function __construct(
        private readonly SaleRepositoryInterface $sales,
        private readonly SaleCalculator $calculator,
        private readonly LoyaltyService $loyalty,
        private readonly SettingsService $settings,
    ) {}

    /** @param array<string,mixed> $data */
    /**
     * Make a draft bill — or, with $existing, change a draft bill (same bill
     * number). A confirmed or cancelled bill cannot be changed.
     */
    public function handle(int|string $companyId, array $data, ?int $userId = null, ?Sale $existing = null): Sale
    {
        if ($existing && $existing->status !== 'draft') {
            throw ValidationException::withMessages(['sale' => 'Only a draft bill can be edited. A confirmed bill cannot be changed — make a sales return or ask for cancellation.']);
        }
        $billKind = $data['bill_kind'] ?? 'tax_invoice';
        if (! in_array($billKind, ['tax_invoice', 'proforma', 'complimentary'], true)) {
            throw ValidationException::withMessages(['bill_kind' => 'Invalid bill type.']);
        }

        $this->assertDiscountCeiling($companyId, $data['items'] ?? [], $billKind);

        $computed = $this->calculator->compute($data['items'], (bool) ($data['is_interstate'] ?? false));

        $customerName = $data['customer_name'] ?? null;
        $customer = null;
        if (! empty($data['customer_id'])) {
            $customer = Customer::forCompany($companyId)->find($data['customer_id']);
            $customerName = $customer?->name ?? $customerName;
        }
        $customerName ??= 'Walk-in';

        $billTotal = (float) $computed['totals']['grand_total'];
        $redeemPoints = (int) ($data['loyalty_points_redeemed'] ?? 0);
        $loyaltyDiscount = 0.0;

        if ($redeemPoints > 0) {
            if (! $customer) {
                throw ValidationException::withMessages(['loyalty_points_redeemed' => 'Select a customer to redeem loyalty points.']);
            }
            $min = $this->loyalty->minimumRedeemPoints($companyId);
            if ($min > 0 && $redeemPoints < $min) {
                throw ValidationException::withMessages([
                    'loyalty_points_redeemed' => "Redeem at least {$min} points.",
                ]);
            }
            $max = $this->loyalty->maxRedeemable($companyId, $customer, $billTotal);
            if ($redeemPoints > $max) {
                throw ValidationException::withMessages([
                    'loyalty_points_redeemed' => "Cannot redeem more than {$max} points on this bill.",
                ]);
            }
            $loyaltyDiscount = $this->loyalty->discountForPoints($companyId, $redeemPoints);
        }

        // Money taken cannot be more than the bill (after points). Change given
        // back is not "paid" — over-paying would leave the customer owing a minus amount.
        $payable = max(0, $billTotal - $loyaltyDiscount);

        // Pay part (or all) of the bill from the customer's advance — e.g. money
        // from an earlier sales return. Taken from the advance when confirmed.
        $useAdvance = round(max(0, (float) ($data['use_advance'] ?? 0)), 2);
        if ($useAdvance > 0.005) {
            if (! $customer) {
                throw ValidationException::withMessages(['use_advance' => 'Select a customer to pay from their advance.']);
            }
            $available = round((float) $customer->advance_balance, 2);
            if ($useAdvance > $available + 0.005) {
                throw ValidationException::withMessages(['use_advance' => sprintf('Only ₹%.2f advance is available for %s.', $available, $customer->name)]);
            }
            if ($useAdvance > $payable + 0.005) {
                throw ValidationException::withMessages(['use_advance' => sprintf('Advance used (₹%.2f) cannot be more than the bill (₹%.2f).', $useAdvance, $payable)]);
            }
        }
        $data['use_advance'] = $useAdvance;
        $payable = max(0, round($payable - $useAdvance, 2));

        // A walk-in (no customer) cannot owe money.
        if (empty($data['customer_id']) && $billKind !== 'complimentary' && isset($data['amount_paid']) && $data['amount_paid'] !== ''
            && (float) $data['amount_paid'] + 0.005 < $payable) {
            throw ValidationException::withMessages(['amount_paid' => sprintf('A walk-in bill must be paid in full (₹%.2f). Pick a customer to leave part unpaid.', $payable)]);
        }
        if (isset($data['amount_paid']) && $data['amount_paid'] !== '' && (float) $data['amount_paid'] > $payable + 0.005) {
            throw ValidationException::withMessages([
                'amount_paid' => sprintf('Amount paid (₹%.2f) cannot be more than the bill total (₹%.2f). Enter the bill amount and give the change back.', (float) $data['amount_paid'], $payable),
            ]);
        }

        $productMeta = Product::forCompany($companyId)
            ->whereIn('id', collect($data['items'])->pluck('product_id')->filter())
            ->get(['id', 'name', 'hsn_code'])
            ->keyBy('id');

        // A retail customer always gets the retail price tier (it cannot be changed on the bill).
        $retailOnly = $customer && ($customer->type?->value ?? $customer->type) === 'retail';

        return DB::transaction(function () use ($companyId, $data, $computed, $customerName, $productMeta, $redeemPoints, $loyaltyDiscount, $billTotal, $billKind, $userId, $retailOnly, $existing) {
            $t = $computed['totals'];
            $due = max(0, round($billTotal - $loyaltyDiscount - (float) $data['use_advance'], 2));
            $fields = [
                'company_id'              => $companyId,
                'customer_id'             => $data['customer_id'] ?? null,
                'location_id'             => $data['location_id'] ?? null,
                'customer_name'           => $customerName,
                'sale_no'                 => $this->sales->nextSaleNo($companyId),
                'sale_date'               => $data['sale_date'],
                'is_interstate'           => (bool) ($data['is_interstate'] ?? false),
                'payment_mode'            => $data['payment_mode'] ?? 'cash',
                'bill_kind'               => $billKind,
                'created_by'              => $userId,
                'subtotal'                => $t['subtotal'],
                'tax_total'               => $t['tax_total'],
                'round_off'               => $t['round_off'],
                'grand_total'             => $t['grand_total'],
                // Not given: cash/card/UPI = paid in full; credit = nothing paid yet.
                'amount_paid'             => (isset($data['amount_paid']) && $data['amount_paid'] !== '') ? $data['amount_paid'] : (($data['payment_mode'] ?? 'cash') === 'credit' ? 0 : $due),
                'loyalty_points_redeemed' => $redeemPoints,
                'loyalty_discount'        => $loyaltyDiscount,
                'use_advance'             => $data['use_advance'],
                'status'                  => 'draft',
                'notes'                   => $data['notes'] ?? null,
            ];
            if ($existing) {
                $sale = Sale::query()->lockForUpdate()->findOrFail($existing->id);
                if ($sale->status !== 'draft') {
                    throw ValidationException::withMessages(['sale' => 'Only a draft bill can be edited.']);
                }
                // Keep the bill number, who made it and its company.
                unset($fields['sale_no'], $fields['created_by'], $fields['company_id']);
                $sale->fill($fields)->save();
                $sale->items()->delete();
            } else {
                $sale = $this->sales->create($fields);
            }

            $rows = [];
            foreach ($data['items'] as $i => $item) {
                $calc = $computed['lines'][$i];
                $meta = $productMeta[$item['product_id']] ?? null;
                $rows[] = [
                    'product_id'    => $item['product_id'],
                    'product_batch_id' => $item['product_batch_id'] ?? null,
                    'product_name'  => $meta->name ?? 'Item',
                    'hsn_code'      => $meta->hsn_code ?? null,
                    'qty'           => $item['qty'],
                    'rate'          => $item['rate'],
                    'price_level'   => $retailOnly ? 'retail' : ($item['price_level'] ?? 'retail'),
                    'discount'      => $item['discount'] ?? 0,
                    'gst_rate'      => $item['gst_rate'] ?? 0,
                    'taxable_value' => $calc['taxable_value'],
                    'cgst_amount'   => $calc['cgst_amount'],
                    'sgst_amount'   => $calc['sgst_amount'],
                    'igst_amount'   => $calc['igst_amount'],
                    'line_total'    => $calc['line_total'],
                ];
            }
            $sale->items()->createMany($rows);

            return $sale->load(['items', 'customer:id,name,type,loyalty_points']);
        });
    }

    /** Enforce HO-configured max line discount as % of (qty × rate). Skipped for complimentary bills. */
    private function assertDiscountCeiling(int|string $companyId, array $items, string $billKind = 'tax_invoice'): void
    {
        if ($billKind === 'complimentary') {
            return;
        }
        $ceiling = $this->settings->getFloat($companyId, 'discount_ceiling_percent');
        if ($ceiling <= 0) {
            return;
        }

        foreach ($items as $i => $item) {
            $qty = (float) ($item['qty'] ?? 0);
            $rate = (float) ($item['rate'] ?? 0);
            $discount = (float) ($item['discount'] ?? 0);
            $base = $qty * $rate;
            if ($base <= 0) {
                continue;
            }
            $pct = ($discount / $base) * 100;
            if ($pct > $ceiling + 0.01) {
                throw ValidationException::withMessages([
                    "items.{$i}.discount" => "Discount exceeds the {$ceiling}% ceiling set in Settings.",
                ]);
            }
        }
    }
}
