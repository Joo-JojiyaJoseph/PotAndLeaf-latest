<?php

namespace App\Http\Resources;

use App\Models\Sale;
use App\Services\SettingsService;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin Sale */
class SaleResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $user = $request->user();
        $companyId = $this->company_id;
        $settings = app(SettingsService::class);
        $cancelRequiresApproval = $settings->get($companyId, 'sale_cancel_requires_approval') === '1';

        return [
            'id'            => $this->id,
            'company_id'    => $this->company_id,
            'sale_no'       => $this->sale_no,
            'sale_date'     => optional($this->sale_date)->toDateString(),
            'customer_id'   => $this->customer_id,
            'customer_name' => $this->customer_name,
            'company'       => $this->whenLoaded('company', fn () => [
                'name' => $this->company->name, 'legal_name' => $this->company->legal_name,
                'gst_number' => $this->company->gst_number, 'address' => $this->company->address,
                'phone' => $this->company->phone, 'email' => $this->company->email,
                'state' => $this->company->state, 'state_code' => $this->company->state_code,
            ]),
            'customer'      => $this->whenLoaded('customer', fn () => $this->customer ? [
                'id' => $this->customer->id, 'name' => $this->customer->name, 'type' => $this->customer->type?->value,
            ] : null),
            'is_interstate' => (bool) $this->is_interstate,
            'payment_mode'  => $this->payment_mode,
            'bill_kind'     => $this->bill_kind ?? 'tax_invoice',
            'subtotal'      => (float) $this->subtotal,
            'tax_total'     => (float) $this->tax_total,
            'round_off'     => (float) $this->round_off,
            'grand_total'             => (float) $this->grand_total,
            'amount_paid'             => (float) $this->amount_paid,
            'use_advance'             => (float) $this->use_advance,
            // Goods brought back (confirmed sales returns) are not paid for.
            'returned'                => $this->resource->returnedTotal(),
            'balance'                 => $this->resource->balanceDue(),
            'loyalty_points_redeemed' => (int) $this->loyalty_points_redeemed,
            'loyalty_discount'        => (float) $this->loyalty_discount,
            'payment_status'          => $this->paymentStatus(),
            'bill_type'               => $this->whenLoaded('customer', fn () => $this->customer?->type?->value),
            'status'                  => $this->status,
            'notes'         => $this->notes,
            'confirmed_at'  => optional($this->confirmed_at)->toIso8601String(),
            'cancel_requested_at'     => optional($this->cancel_requested_at)->toIso8601String(),
            'cancel_reason'           => $this->cancel_reason,
            'cancel_rejection_reason' => $this->cancel_rejection_reason,
            'cancel_requested_by'     => $this->whenLoaded('cancelRequestedBy', fn () => $this->cancelRequestedBy?->name),
            'cancel_reviewed_by'      => $this->whenLoaded('cancelReviewedBy', fn () => $this->cancelReviewedBy?->name),
            'entered_by'    => $this->whenLoaded('createdBy', fn () => $this->createdBy?->name),
            'created_by'    => $this->created_by,
            'items_count'   => $this->when($this->items_count !== null, $this->items_count),
            'items'         => SaleItemResource::collection($this->whenLoaded('items')),
            // Draft lines that need more than is in stock now (for "Request shortage").
            'short_items'   => $shortItems = $this->shortItems(),
            'can'           => [
                'confirm'         => $this->status === 'draft' && $user?->hasPermission('sales.confirm', $companyId),
                // A draft bill can be changed; once confirmed it cannot.
                'edit'            => $this->status === 'draft' && $user?->hasPermission('sales.create', $companyId),
                // Only when some item is short of stock and there is a customer to wait for it.
                'request_shortage' => $this->status === 'draft' && $this->customer_id && $shortItems !== [],
                'cancel'          => $this->status !== 'cancelled'
                    && ! $this->hasCancelRequest()
                    && (
                        (in_array($this->status, ['draft', 'proforma'], true) && $user?->hasPermission('sales.delete', $companyId))
                        || ($this->isConfirmed() && ! $cancelRequiresApproval && $user?->hasPermission('sales.delete', $companyId))
                    ),
                'cancel_request'  => $this->isConfirmed()
                    && ! $this->hasCancelRequest()
                    && $cancelRequiresApproval
                    && $user?->hasPermission('sales.cancel_request', $companyId),
                'cancel_approve'  => $this->hasCancelRequest() && $user?->hasPermission('sales.cancel_approve', $companyId),
                'cancel_reject'   => $this->hasCancelRequest() && $user?->hasPermission('sales.cancel_approve', $companyId),
                'whatsapp'        => in_array($this->status, ['confirmed', 'proforma'], true)
                    && $user?->hasPermission('sales.whatsapp', $companyId),
                'convert_proforma'=> $this->isProforma() && $user?->hasPermission('sales.confirm', $companyId),
            ],
        ];
    }

    /** @return array<string,float> sale item id → how many are missing (draft sales only). */
    private function shortItems(): array
    {
        if ($this->status !== 'draft' || ! $this->relationLoaded('items')) {
            return [];
        }
        $stock = \App\Models\Product::query()->whereIn('id', $this->items->pluck('product_id')->filter())->pluck('current_stock', 'id');
        $out = [];
        foreach ($this->items as $item) {
            if (! $item->product_id) {
                continue;
            }
            $short = round((float) $item->qty - (float) ($stock[$item->product_id] ?? 0), 3);
            if ($short > 0.0005) {
                $out[$item->id] = $short;
            }
        }

        return $out;
    }
}
