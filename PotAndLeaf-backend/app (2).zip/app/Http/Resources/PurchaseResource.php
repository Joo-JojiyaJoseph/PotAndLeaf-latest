<?php

namespace App\Http\Resources;

use App\Models\Purchase;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin Purchase */
class PurchaseResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $user = $request->user();
        $companyId = $this->company_id;
        // What is owed to the supplier for this bill. Fixed when confirmed; for a draft
        // it follows Settings → "Freight / loading on purchases is paid to the supplier".
        $payable = $this->status === 'confirmed'
            ? $this->supplierPayable()
            : round((float) $this->grand_total - (app(\App\Services\SettingsService::class)->get($companyId, 'landed_cost_payable_to_supplier') === '0' ? (float) $this->landed_cost_total : 0.0), 2);

        return [
            'id'                => $this->id,
            'company_id'        => $this->company_id,
            'purchase_no'       => $this->purchase_no,
            'invoice_no'        => $this->invoice_no,
            'invoice_date'      => optional($this->invoice_date)->toDateString(),
            'purchase_date'     => optional($this->purchase_date)->toDateString(),
            'location_id'       => $this->location_id,
            'location'          => $this->whenLoaded('location', fn () => $this->location ? ['id' => $this->location->id, 'name' => $this->location->name, 'type' => $this->location->type] : null),
            'is_interstate'     => (bool) $this->is_interstate,
            'subtotal'          => (float) $this->subtotal,
            'discount_total'    => (float) $this->discount_total,
            'tax_total'         => (float) $this->tax_total,
            'landed_cost_total' => (float) $this->landed_cost_total,
            'agent_code'        => $this->agent_code,
            'final_discount'    => (float) ($this->final_discount ?? 0),
            'grand_total'       => (float) $this->grand_total,
            'amount_paid'       => (float) $this->amount_paid,
            'supplier_payable'  => $payable,
            // Freight / loading paid to a transporter, not to this supplier.
            'freight_to_transporter' => round(max(0, (float) $this->grand_total - $payable), 2),
            'balance'           => round($payable - (float) $this->amount_paid, 2),
            'payment_status'    => $this->paymentStatus(),
            'status'            => $this->status,
            'notes'             => $this->notes,
            // Made from a purchase order: the supplier is fixed by that order.
            'purchase_order'    => $this->whenLoaded('purchaseOrder', fn () => $this->purchaseOrder ? ['id' => $this->purchaseOrder->id, 'po_no' => $this->purchaseOrder->po_no] : null),
            'confirmed_at'      => optional($this->confirmed_at)->toIso8601String(),
            'entered_by'        => $this->whenLoaded('createdBy', fn () => $this->createdBy?->name),
            'created_by'        => $this->created_by,
            'items_count'       => $this->when($this->items_count !== null, $this->items_count),
            'company'           => $this->whenLoaded('company', fn () => [
                'name' => $this->company->name, 'legal_name' => $this->company->legal_name,
                'gst_number' => $this->company->gst_number, 'address' => $this->company->address,
                'phone' => $this->company->phone, 'state' => $this->company->state, 'state_code' => $this->company->state_code,
            ]),
            'supplier'          => $this->whenLoaded('supplier', fn () => [
                'id'            => $this->supplier?->id,
                'name'          => $this->supplier?->name,
                'supplier_code' => $this->supplier?->supplier_code,
            ]),
            'items'             => PurchaseItemResource::collection($this->whenLoaded('items')),
            // Every payment that went to this bill: paid for the bill directly, an
            // outstanding payment that was applied to it (oldest first), or advance used on it.
            'payments'          => $this->when(
                $this->relationLoaded('supplierPayments') && $this->relationLoaded('paymentAllocations'),
                fn () => $this->paymentRows(),
            ),
            'can'               => [
                'update'  => $this->status === 'draft' && $user?->hasPermission('purchases.update', $companyId),
                'confirm' => $this->status === 'draft' && $user?->hasPermission('purchases.confirm', $companyId),
                'cancel'  => $this->status === 'draft' && $user?->hasPermission('purchases.delete', $companyId),
            ],
        ];
    }
}
