<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Purchase;
use App\Models\PurchaseOrder;
use App\Models\RentalInvoice;
use App\Models\Sale;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class InvoicePdfController extends Controller
{
    public function sale(Request $request, Sale $sale): Response
    {
        $company = $request->attributes->get('company');
        abort_unless($request->user()->hasPermission('sales.view', $company->id), 403);
        $this->assertRecordCompany($request, (string) $sale->company_id);
        abort_if($request->user()->seesOnlyOwn('sales', $sale->company_id) && (int) $sale->created_by !== (int) $request->user()->id, 403, 'You can only see the bills you made.');

        $sale->load([
            'items',
            'customer:id,name,type,gst_number,phone,address_line1,city,state',
            'company:id,name,legal_name,gst_number,address,phone,email,state,state_code',
        ]);

        $pdf = Pdf::loadView('pdf.sale-invoice', ['sale' => $sale])
            ->setPaper('a4');

        return $pdf->download("invoice-{$sale->sale_no}.pdf");
    }

    public function purchase(Request $request, Purchase $purchase): Response
    {
        $company = $request->attributes->get('company');
        abort_unless($request->user()->hasPermission('purchases.view', $company->id), 403);
        $this->assertRecordCompany($request, (string) $purchase->company_id);

        $purchase->load([
            'items',
            'supplier:id,name,supplier_code,gst_number,phone,address_line1,city,state',
            'company:id,name,legal_name,gst_number,address,phone,email,state,state_code',
        ]);

        $pdf = Pdf::loadView('pdf.purchase-grn', ['purchase' => $purchase])
            ->setPaper('a4');

        return $pdf->download("grn-{$purchase->purchase_no}.pdf");
    }

    public function purchaseOrder(Request $request, PurchaseOrder $purchaseOrder): Response
    {
        $company = $request->attributes->get('company');
        abort_unless($request->user()->hasPermission('po.view', $company->id), 403);
        $this->assertRecordCompany($request, (string) $purchaseOrder->company_id);

        $purchaseOrder->load([
            'items.product:id,sku,name,unit_id',
            'items.product.unit:id,name,short_name',
            'supplier',
            'company:id,name,legal_name,gst_number,address,phone,email,state,state_code,logo',
            'createdBy:id,name',
        ]);

        $pdf = Pdf::loadView('pdf.purchase-order', ['po' => $purchaseOrder])
            ->setPaper('a4');

        return $pdf->download("po-{$purchaseOrder->po_no}.pdf");
    }

    public function rental(Request $request, RentalInvoice $rentalInvoice): Response
    {
        $company = $request->attributes->get('company');
        abort_unless($request->user()->hasPermission('rental.view', $company->id), 403);
        $this->assertRecordCompany($request, (string) $rentalInvoice->company_id);

        $rentalInvoice->load([
            'rental.items',
            'rental.customer:id,name,phone,whatsapp,address_line1,city,state',
            'rental.company:id,name,legal_name,gst_number,address,phone,email,state,state_code',
        ]);

        $pdf = Pdf::loadView('pdf.rental-invoice', ['invoice' => $rentalInvoice, 'rental' => $rentalInvoice->rental])
            ->setPaper('a4');

        return $pdf->download("rental-invoice-{$rentalInvoice->invoice_no}.pdf");
    }

    /** Match record company to header, ?company_id=, or super-admin global read. */
    private function assertRecordCompany(Request $request, string $recordCompanyId): void
    {
        $headerId = (string) $request->attributes->get('company')->id;

        if ($recordCompanyId === $headerId) {
            return;
        }

        if (filled($request->query('company_id')) && $recordCompanyId === (string) $request->query('company_id')) {
            return;
        }

        if ($request->user()->is_super_admin) {
            return;
        }

        abort(404);
    }
}
