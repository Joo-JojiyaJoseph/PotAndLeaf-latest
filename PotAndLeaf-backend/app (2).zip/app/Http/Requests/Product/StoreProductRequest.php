<?php

namespace App\Http\Requests\Product;

use App\Enums\ProductStatus;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Enum;

class StoreProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        $companyId = $this->route('current_company')?->id;

        return $this->user()->hasPermission('products.create', $companyId);
    }

    public function rules(): array
    {
        $companyId = $this->route('current_company')->id;

        return array_merge($this->baseRules($companyId, null), [
            'sku' => [
                'nullable', 'string', 'max:50',
                Rule::unique('products', 'sku')->where('company_id', $companyId),
            ],
        ]);
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Name is required.',
            'name.unique'   => 'A product with this name already exists in this company.',
            'sku.unique'    => 'This SKU is already used by another product in this company.',
            'category_id.required' => 'Category is required.',
            'category_id.exists'   => 'Selected category is inactive or invalid.',
            'cost_price.required'  => 'Cost price is required.',
            'cost_price.numeric'   => 'Cost price must be a number.',
        ];
    }

    /** GST rates in use in India (%). */
    public const GST_RATES = [0, 0.1, 0.25, 1, 1.5, 3, 5, 6, 7.5, 12, 14, 18, 28, 40];

    /** A selling price may not be more than the printed MRP (when an MRP is given). */
    protected function notAboveMrp(): \Closure
    {
        return function (string $attribute, mixed $value, \Closure $fail) {
            $mrp = (float) $this->input('mrp');
            if ($mrp > 0 && is_numeric($value) && (float) $value > $mrp + 0.001) {
                $label = ucfirst(str_replace('_', ' ', $attribute));
                $fail("{$label} (₹{$value}) cannot be more than the MRP (₹{$mrp}).");
            }
        };
    }

    /**
     * A selling price may not be below the cost price (you would lose money on
     * every piece). An empty / 0 price is "not used" and is not checked.
     */
    protected function notBelowCost(): \Closure
    {
        return function (string $attribute, mixed $value, \Closure $fail) {
            $cost = (float) $this->input('cost_price');
            if ($cost > 0 && is_numeric($value) && (float) $value > 0 && (float) $value < $cost - 0.001) {
                $label = ucfirst(str_replace('_', ' ', $attribute));
                $fail("{$label} (₹{$value}) is below the cost price (₹{$cost}). You would lose money on every piece.");
            }
        };
    }

    /** Shared field rules, reused by the update request. */
    protected function baseRules(int|string $companyId, ?string $ignoreId): array
    {
        return [
            'name'            => [
                'required', 'string', 'max:191',
                Rule::unique('products', 'name')->where('company_id', $companyId)->ignore($ignoreId),
            ],
            'barcode'         => ['nullable', 'string', 'max:100'],
            'hsn_code'        => ['nullable', 'string', 'max:20'],
            'description'     => ['nullable', 'string', 'max:2000'],
            'category_id'     => [
                'required', 'uuid',
                Rule::exists('product_categories', 'id')
                    ->where('company_id', $companyId)
                    ->where('status', 'active'),
            ],
            'brand_id'        => ['nullable', 'uuid', Rule::exists('product_brands', 'id')->where('company_id', $companyId)],
            'unit_id'         => ['nullable', 'uuid', Rule::exists('product_units', 'id')->where('company_id', $companyId)],
            'gst_rate'        => ['nullable', 'numeric', function (string $a, mixed $v, \Closure $fail) {
                if (is_numeric($v) && ! collect(self::GST_RATES)->contains(fn ($r) => abs($r - (float) $v) < 0.001)) {
                    $fail('GST % must be one of: '.implode(', ', self::GST_RATES).'.');
                }
            }],
            'mrp'             => ['nullable', 'numeric', 'min:0'],
            'cost_price'      => ['required', 'numeric', 'min:0'],
            'dealer_price'    => ['nullable', 'numeric', 'min:0', $this->notAboveMrp(), $this->notBelowCost()],
            'wholesale_price' => ['nullable', 'numeric', 'min:0', $this->notAboveMrp(), $this->notBelowCost()],
            'retail_price'    => ['nullable', 'numeric', 'min:0', $this->notAboveMrp(), $this->notBelowCost()],
            'length_cm'       => ['nullable', 'numeric', 'min:0'],
            'width_cm'        => ['nullable', 'numeric', 'min:0'],
            'height_cm'       => ['nullable', 'numeric', 'min:0'],
            'reorder_level'   => ['nullable', 'numeric', 'min:0'],
            'opening_stock'   => ['nullable', 'numeric', 'min:0'],
            'images'          => ['nullable', 'array'],
            'images.*'        => ['string'],
            'status'          => ['required', new Enum(ProductStatus::class)],
            'is_rental'       => ['sometimes', 'boolean'],
            'rental_daily_rate' => ['nullable', 'numeric', 'min:0'],

            'suppliers'                 => ['nullable', 'array'],
            'suppliers.*.supplier_id'   => ['required', 'uuid', Rule::exists('suppliers', 'id')->where('company_id', $companyId)],
            'suppliers.*.supplier_price' => ['nullable', 'numeric', 'min:0'],
            'suppliers.*.is_primary'    => ['nullable', 'boolean'],
        ];
    }
}
