<?php

namespace App\Models;

use App\Models\Concerns\HasAuditColumns;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Sale extends Model
{
    use HasAuditColumns, HasFactory, HasUuids;

    protected $fillable = [
        'company_id', 'customer_id', 'location_id', 'customer_name', 'sale_no', 'sale_date',
            'is_interstate', 'payment_mode', 'bill_kind', 'converted_from_sale_id', 'subtotal', 'tax_total', 'round_off',
            'grand_total', 'amount_paid', 'use_advance', 'loyalty_points_redeemed', 'loyalty_discount',
            'status', 'notes', 'confirmed_at',
            'cancel_requested_at', 'cancel_requested_by', 'cancel_reason',
            'cancel_reviewed_at', 'cancel_reviewed_by', 'cancel_rejection_reason',
            'created_by',
    ];

    protected function casts(): array
    {
        return [
            'sale_date'               => 'date',
            'is_interstate'           => 'boolean',
            'subtotal'                => 'decimal:2',
            'tax_total'               => 'decimal:2',
            'round_off'               => 'decimal:2',
            'grand_total'             => 'decimal:2',
            'amount_paid'             => 'decimal:2',
            'use_advance'             => 'decimal:2',
            'loyalty_points_redeemed' => 'integer',
            'loyalty_discount'        => 'decimal:2',
            'confirmed_at'            => 'datetime',
            'cancel_requested_at'     => 'datetime',
            'cancel_reviewed_at'      => 'datetime',
        ];
    }

    public function cancelRequestedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'cancel_requested_by');
    }

    public function cancelReviewedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'cancel_reviewed_by');
    }

    public function convertedFrom(): BelongsTo
    {
        return $this->belongsTo(Sale::class, 'converted_from_sale_id');
    }

    public function isProforma(): bool
    {
        return $this->status === 'proforma';
    }

    public function isComplimentary(): bool
    {
        return $this->bill_kind === 'complimentary';
    }

    public function hasCancelRequest(): bool
    {
        return $this->cancel_requested_at !== null && $this->status === 'confirmed';
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(SaleItem::class);
    }

    public function salesReturns(): HasMany
    {
        return $this->hasMany(SalesReturn::class, 'sale_id');
    }

    /** Value of confirmed sales returns against this bill (goods brought back). */
    public function returnedTotal(): float
    {
        if (array_key_exists('returned_sum', $this->getAttributes())) {
            return round((float) $this->getAttributes()['returned_sum'], 2);
        }

        return round((float) $this->salesReturns()->where('status', 'confirmed')->sum('grand_total'), 2);
    }

    /** Still to pay on this bill: bill − points discount − paid − returned. */
    public function balanceDue(): float
    {
        return round(max(0, (float) $this->grand_total - (float) $this->loyalty_discount - (float) $this->amount_paid - $this->returnedTotal()), 2);
    }

    public function customerReceipts(): HasMany
    {
        return $this->hasMany(CustomerReceipt::class);
    }

    public function receiptAllocations(): HasMany
    {
        return $this->hasMany(CustomerReceiptAllocation::class);
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function scopeForCompany($query, int|string $companyId)
    {
        return $query->where('company_id', $companyId);
    }

    public function isDraft(): bool
    {
        return $this->status === 'draft';
    }

    public function isConfirmed(): bool
    {
        return $this->status === 'confirmed';
    }

    public function paymentStatus(): string
    {
        if ($this->status !== 'confirmed') {
            return 'n/a';
        }
        // Goods brought back are not paid for: settled when paid + returned covers it.
        $due = max(0, (float) $this->grand_total - (float) $this->loyalty_discount - $this->returnedTotal());
        $paid = (float) $this->amount_paid;
        if ($due <= 0.01) {
            return 'paid';
        }
        if ($paid <= 0) {
            return 'unpaid';
        }
        if ($paid + 0.01 < $due) {
            return 'partial';
        }

        return 'paid';
    }
}
