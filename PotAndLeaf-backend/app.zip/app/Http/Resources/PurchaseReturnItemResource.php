<?php

namespace App\Http\Resources;

use App\Models\PurchaseReturnItem;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin PurchaseReturnItem */
class PurchaseReturnItemResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'               => $this->id,
            'purchase_item_id' => $this->purchase_item_id,
            'product_id'       => $this->product_id,
            'product_batch_id' => $this->product_batch_id,
            'damage_entry_id'  => $this->damage_entry_id,
            'product_name'     => $this->product_name,
            'hsn_code'         => $this->hsn_code,
            'qty'              => (float) $this->qty,
            'rate'             => (float) $this->rate,
            'gst_rate'         => (float) $this->gst_rate,
            'taxable_value'    => (float) $this->taxable_value,
            'cgst_amount'      => (float) $this->cgst_amount,
            'sgst_amount'      => (float) $this->sgst_amount,
            'igst_amount'      => (float) $this->igst_amount,
            'line_total'       => (float) $this->line_total,
            'unit_cost'        => (float) $this->unit_cost,
            'reason'           => $this->reason,
        ];
    }
}
