<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\StoreUserRequest;
use App\Http\Requests\User\UpdateUserRequest;
use App\Http\Resources\UserResource;
use App\Models\Location;
use App\Models\Role;
use App\Models\User;
use App\Support\Api\ApiResponse;
use App\Support\Api\ResolvesFilterCompany;
use App\Support\ProtectedRecords;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\ValidationException;

/**
 * User management within a company. Each user is a real login (email + password)
 * and gets one company-scoped role. HO super admins can manage users in any
 * company; everyone else needs users.* permissions in the active company.
 */
class UserController extends Controller
{
    use ApiResponse, ResolvesFilterCompany;

    public function index(Request $request): JsonResponse
    {
        $companyId = $this->listCompanyId($request);
        $this->allow($request, 'users.view');

        $status = $request->query('status', 'active');
        abort_unless(in_array($status, ['active', 'inactive', 'all', 'removed'], true), 422, 'Invalid status filter.');
        abort_if($status === 'removed' && ! $request->user()->is_super_admin, 403, 'Only HO super admins can see removed users.');

        try {
            $users = User::query()
                ->companyMembers($companyId, $status)
                ->with([
                    'companies:id,name',
                    // Roles held in the listed company. (Inside when() the query is a plain
                    // builder without wherePivot(); MySQL then failed with "unknown column pivot".)
                    'roles' => fn ($q) => $q->when($companyId !== null, fn ($q2) => $q2->where('role_user.company_id', $companyId)),
                ])
                ->orderBy('name')
                ->paginate(min((int) $request->integer('per_page', 25), 100))
                ->withQueryString();
        } catch (\Throwable $e) {
            Log::error('users.index failed', [
                'company_id' => $companyId,
                'status' => $status,
                'message' => $e->getMessage(),
            ]);
            throw $e;
        }

        return $this->ok(UserResource::collection($users));
    }

    /** Roles available to assign in this company. */
    public function formData(Request $request): JsonResponse
    {
        $company = $this->listCompany($request);
        $this->allow($request, 'users.view');

        $roles = Role::query()->orderBy('name')->get(['id', 'name']);
        $locations = Location::query()
            ->when($company?->id, fn ($q) => $q->where('company_id', $company->id))
            ->where('is_active', true)->orderByDesc('is_default')->orderBy('name')
            ->get(['id', 'company_id', 'name', 'type', 'is_default']);

        return $this->ok(['roles' => $roles, 'locations' => $locations]);
    }

    public function show(Request $request, User $user): JsonResponse
    {
        $this->allow($request, 'users.view');

        // A removed user belongs to no company; HO can still open the record.
        if ($request->user()->is_super_admin && ! $user->companies()->exists()) {
            return $this->ok(new UserResource($user->load(['companies:id,name'])->setRelation('roles', collect())));
        }

        $companyId = $this->resolveUserCompanyContext($request, $user);

        return $this->ok($this->present($user, $companyId));
    }

    /** Bring a removed user back into the open company (their email stays reserved, so re-adding would fail). */
    public function restore(Request $request, User $user): JsonResponse
    {
        $company = $this->company($request);
        $this->allow($request, 'users.create');
        abort_unless($request->user()->is_super_admin, 403, 'Only HO super admins can restore removed users.');
        abort_if($user->companies()->exists(), 422, 'This user is not removed. Edit them instead.');

        $data = $request->validate(['role_id' => ['nullable', 'uuid', 'exists:roles,id']]);

        DB::transaction(function () use ($user, $company, $data) {
            $user->companies()->syncWithoutDetaching([$company->id => ['is_default' => true]]);
            $this->syncCompanyRole($user, $company->id, $data['role_id'] ?? null);
            $user->update(['is_active' => true]);
        });

        return $this->ok($this->present($user->refresh(), $company->id), 'User restored to '.$company->name.'.');
    }

    public function store(StoreUserRequest $request): JsonResponse
    {
        $company = $this->company($request);
        $data = $request->validated();

        $user = DB::transaction(function () use ($company, $data) {
            $user = User::create([
                'name'      => $data['name'],
                'email'     => $data['email'],
                'password'  => Hash::make($data['password']),
                'phone'     => $data['phone'] ?? null,
                'is_active' => $data['is_active'] ?? true,
            ]);
            $user->companies()->syncWithoutDetaching([$company->id => ['is_default' => true]]);
            $this->syncCompanyRole($user, $company->id, $data['role_id'] ?? null);
            $this->syncLocation($user, $company->id, $data['location_id'] ?? null);

            return $user;
        });

        return $this->created($this->present($user, $company->id), 'User created.');
    }

    public function update(UpdateUserRequest $request, User $user): JsonResponse
    {
        $companyId = $this->resolveUserCompanyContext($request, $user);
        $data = $request->validated();
        $targetCompanyId = $companyId;

        DB::transaction(function () use ($user, $companyId, $data, $request, &$targetCompanyId) {
            $user->fill([
                'name'      => $data['name'],
                'email'     => $data['email'],
                'phone'     => $data['phone'] ?? null,
                'is_active' => $data['is_active'] ?? $user->is_active,
            ]);
            if (! empty($data['password'])) {
                $user->password = Hash::make($data['password']);
            }
            $user->save();

            $roleId = $data['role_id'] ?? null;

            if ($request->user()->is_super_admin && filled($data['target_company_id'] ?? null)) {
                $newCompanyId = $data['target_company_id'];
                if ((string) $newCompanyId !== (string) $companyId) {
                    $this->syncCompanyRole($user, $companyId, null);
                    $user->companies()->detach($companyId);
                    $user->companies()->syncWithoutDetaching([$newCompanyId => ['is_default' => true]]);
                    $targetCompanyId = $newCompanyId;
                }
            }

            $this->syncCompanyRole($user, $targetCompanyId, $roleId);
            if (array_key_exists('location_id', $data) || (string) $targetCompanyId !== (string) $companyId) {
                $this->syncLocation($user, $targetCompanyId, $data['location_id'] ?? null);
            }
        });

        return $this->ok($this->present($user->refresh(), $targetCompanyId), 'User updated.');
    }

    public function destroy(Request $request, User $user): JsonResponse
    {
        $companyId = $this->resolveUserCompanyContext($request, $user);
        $this->allow($request, 'users.delete');

        abort_if(ProtectedRecords::isProtectedUser($user) && $this->company($request)->code === ProtectedRecords::HO_COMPANY_CODE, 403, 'The default HO admin cannot be removed from this company.');

        DB::transaction(function () use ($user, $companyId) {
            $this->syncCompanyRole($user, $companyId, null);
            $user->companies()->detach($companyId);

            if (! $user->is_super_admin && ! $user->companies()->exists()) {
                $user->tokens()->delete();
                $user->update(['is_active' => false]);
            }
        });

        return $this->message('User removed from this company.');
    }

    /** Replace the user's role for this company with (at most) one global role. */
    private function syncCompanyRole(User $user, int|string $companyId, ?string $roleId): void
    {
        DB::table('role_user')
            ->where('user_id', $user->id)
            ->where('company_id', $companyId)
            ->delete();

        if ($roleId) {
            DB::table('role_user')->insert([
                'user_id'    => $user->id,
                'company_id' => $companyId,
                'role_id'    => $roleId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $this->followRoleInCommission($user, $companyId, $roleId);
        }
    }

    /**
     * New role for someone who already has a staff commission rate: change that
     * same rate to match (Supervisor = paid for what they grow/make, Salesman =
     * paid on sales). The rates themselves stay; no second rule is ever made.
     */
    private function followRoleInCommission(User $user, int|string $companyId, string $roleId): void
    {
        $rule = \App\Models\CommissionRule::query()->where('company_id', $companyId)->where('user_id', $user->id)->first();
        if (! $rule) {
            return;
        }
        $role = DB::table('roles')->where('id', $roleId)->first(['slug', 'name']);
        $text = strtolower(($role->slug ?? '').' '.($role->name ?? ''));
        if (str_contains($text, 'supervisor')) {
            $rule->update(['is_supervisor' => true]);
        } elseif (str_contains($text, 'sales') || str_contains($text, 'cashier')) {
            $rule->update(['is_supervisor' => false]);
        }
    }

    /** Set (or clear) the branch / godown a user works at in a company. */
    private function syncLocation(User $user, int|string $companyId, ?string $locationId): void
    {
        if (! Schema::hasColumn('company_user', 'location_id')) {
            return;
        }
        if (filled($locationId)) {
            $ok = Location::where('company_id', $companyId)->where('is_active', true)->whereKey($locationId)->exists();
            if (! $ok) {
                throw ValidationException::withMessages(['location_id' => 'Choose a branch or godown of this company.']);
            }
        }

        DB::table('company_user')->where('user_id', $user->id)->where('company_id', $companyId)
            ->update(['location_id' => filled($locationId) ? $locationId : null]);
        $user->forgetPermissionCache();
    }

    private function present(User $user, int|string $companyId): UserResource
    {
        $user->load([
            'companies:id,name',
            'roles' => fn ($q) => $q->wherePivot('company_id', $companyId),
        ]);
        $locationId = $user->locationIdFor($companyId);
        $location = $locationId ? Location::find($locationId, ['id', 'name', 'type']) : null;
        $user->setAttribute('location_info', $location ? ['id' => $location->id, 'name' => $location->name, 'type' => $location->type] : null);

        return new UserResource($user);
    }

    /** Resolve which company context to use for show/update/delete. */
    private function resolveUserCompanyContext(Request $request, User $user): int|string
    {
        $headerCompanyId = $this->company($request)->id;

        if ($user->companies()->whereKey($headerCompanyId)->exists()) {
            return $headerCompanyId;
        }

        $param = $request->query('company_id');
        if (filled($param) && $user->companies()->whereKey($param)->exists()) {
            return $param;
        }

        if ($request->user()->is_super_admin) {
            $memberCompany = $user->companies()->value('companies.id');
            abort_unless($memberCompany, 404, 'User has no company membership.');

            return $memberCompany;
        }

        abort(404, 'User is not in this company.');
    }

    private function company(Request $request)
    {
        return $request->attributes->get('company');
    }

    private function allow(Request $request, string $permission): void
    {
        abort_unless($request->user()->hasPermission($permission, $this->company($request)->id), 403);
    }

    public function toggleStatus(Request $request, User $user): JsonResponse
    {
        $companyId = $this->resolveUserCompanyContext($request, $user);
        $this->allow($request, 'users.update');
        abort_if((bool) $user->is_super_admin, 403, 'A super admin cannot be deactivated here.');
        $data = $request->validate(['is_active' => ['required', 'boolean']]);
        $user->update(['is_active' => $data['is_active']]);

        if (! $data['is_active']) {
            $user->tokens()->delete();
        }

        return $this->ok(['id' => $user->id, 'is_active' => (bool) $user->is_active], 'Status updated.');
    }
}
