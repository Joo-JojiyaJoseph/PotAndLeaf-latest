<?php

namespace App\Models;

use App\Models\Concerns\HasAuditColumns;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SupplierPayment extends Model
{
    use HasAuditColumns, HasFactory, HasUuids;

    protected $fillable = [
        'company_id', 'supplier_id', 'purchase_id', 'payment_no',
        'payment_date', 'amount', 'adjusted_amount', 'mode', 'payment_for', 'reference', 'notes',
        'is_advance', 'applied_from_advance', 'discount_for_id',
    ];

    protected function casts(): array
    {
        return [
            'payment_date'         => 'date',
            'amount'               => 'decimal:2',
            'adjusted_amount'      => 'decimal:2',
            'is_advance'           => 'boolean',
            'applied_from_advance' => 'boolean',
        ];
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }

    public function purchase(): BelongsTo
    {
        return $this->belongsTo(Purchase::class);
    }

    public function allocations(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(SupplierPaymentAllocation::class);
    }

    public function scopeForCompany($query, int|string $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
