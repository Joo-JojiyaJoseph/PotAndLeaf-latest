<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Customer\StoreCustomerRequest;
use App\Http\Requests\Customer\UpdateCustomerRequest;
use App\Http\Resources\CustomerResource;
use App\Models\Customer;
use App\Services\CustomerService;
use App\Support\Api\ApiResponse;
use App\Support\Api\AssertsRecordCompany;
use App\Support\Api\ResolvesFilterCompany;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    use ApiResponse, AssertsRecordCompany, ResolvesFilterCompany;

    public function __construct(private readonly CustomerService $customers) {}

    public function index(Request $request): JsonResponse
    {
        $this->allow($request, 'customers.view');

        $filters = $request->only(['search', 'status', 'type', 'per_page']);
        // Salesmen see only the customers they added.
        if ($request->user()->seesOnlyOwn('customers', $this->company($request)->id)) {
            $filters['created_by'] = $request->user()->id;
        }

        return $this->ok(CustomerResource::collection($this->customers->list($this->listCompanyId($request), $filters)));
    }

    /**
     * Short list for "choose a customer" boxes (loyalty points, etc.): every
     * active customer of the company with name, code, phone and points.
     */
    public function options(Request $request): JsonResponse
    {
        $company = $this->company($request);
        $user = $request->user();
        abort_unless(
            collect(['customers.view', 'loyalty.view', 'loyalty.adjust', 'sales.view'])->contains(fn ($p) => $user->hasPermission($p, $company->id)),
            403,
        );

        $rows = Customer::query()
            ->where('company_id', $company->id)
            ->where('status', 'active')
            ->when(filled($request->query('search')), fn ($q) => $q->where(fn ($w) => $w
                ->where('name', 'like', '%'.trim($request->query('search')).'%')
                ->orWhere('customer_code', 'like', '%'.trim($request->query('search')).'%')))
            ->orderBy('name')
            ->limit(1000)
            ->get(['id', 'company_id', 'customer_code', 'name', 'phone', 'type', 'loyalty_points']);

        return $this->ok($rows->map(fn (Customer $c) => [
            'id' => $c->id, 'company_id' => $c->company_id, 'code' => $c->customer_code, 'name' => $c->name,
            'phone' => $c->phone, 'type' => $c->type, 'loyalty_points' => (int) $c->loyalty_points,
        ])->values());
    }

    public function store(StoreCustomerRequest $request): JsonResponse
    {
        $company = $this->company($request);
        $customer = $this->customers->create($company->id, $request->validated());

        return $this->created(new CustomerResource($customer), 'Customer created.');
    }

    public function show(Request $request, Customer $customer): JsonResponse
    {
        $this->allow($request, 'customers.view');
        $this->assertRecordCompany($request, $customer);
        abort_if($request->user()->seesOnlyOwn('customers', $customer->company_id) && (int) $customer->created_by !== (int) $request->user()->id, 403, 'You can only see the customers you added.');

        return $this->ok(new CustomerResource($customer));
    }

    public function update(UpdateCustomerRequest $request, Customer $customer): JsonResponse
    {
        $this->assertRecordCompany($request, $customer, writable: true);

        return $this->ok(new CustomerResource($this->customers->update($customer, $request->validated())), 'Customer updated.');
    }

    public function destroy(Request $request, Customer $customer): JsonResponse
    {
        $this->allow($request, 'customers.delete');
        $this->assertRecordCompany($request, $customer, writable: true);
        \App\Support\Deletion\InUseGuard::assertUnused('customer "'.$customer->name.'"', 'customers', (string) $customer->id, fn ($c) => $c === 'customer_id');
        $this->customers->delete($customer);

        return $this->message('Customer deleted.');
    }

    public function purchaseHistory(Request $request, Customer $customer): JsonResponse
    {
        $this->allow($request, 'customers.view');
        $this->assertRecordCompany($request, $customer);
        abort_if($request->user()->seesOnlyOwn('customers', $customer->company_id) && (int) $customer->created_by !== (int) $request->user()->id, 403, 'You can only see the customers you added.');

        $perPage = min(50, max(1, (int) $request->input('per_page', 15)));
        $paginated = \App\Models\Sale::forCompany($customer->company_id)
            ->where('customer_id', $customer->id)
            ->with(['customer:id,name,type'])
            ->withCount('items')
            ->orderByDesc('sale_date')
            ->orderByDesc('created_at')
            ->paginate($perPage);

        $ledger = \App\Models\LoyaltyLedgerEntry::forCompany($customer->company_id)
            ->where('customer_id', $customer->id)
            ->orderByDesc('created_at')
            ->limit(50)
            ->get()
            ->map(fn ($e) => [
                'id' => $e->id,
                'type' => $e->type,
                'points' => (int) $e->points,
                'balance_after' => (int) $e->balance_after,
                'note' => $e->note,
                'reference_type' => $e->reference_type,
                'reference_id' => $e->reference_id,
                'created_at' => $e->created_at?->toIso8601String(),
            ]);

        $payload = \App\Http\Resources\SaleResource::collection($paginated);
        $response = $this->ok($payload);
        $body = $response->getData(true);
        $body['loyalty'] = [
            'balance' => (int) $customer->loyalty_points,
            'ledger'  => $ledger,
        ];

        return response()->json($body);
    }

    private function company(Request $request)
    {
        return $request->attributes->get('company');
    }

    private function allow(Request $request, string $permission): void
    {
        abort_unless($request->user()->hasPermission($permission, $this->company($request)->id), 403);
    }

    public function toggleStatus(Request $request, Customer $customer): JsonResponse
    {
        $company = $this->company($request);
        abort_unless($request->user()->hasPermission('customers.update', $company->id), 403);
        $this->assertRecordCompany($request, $customer, writable: true);
        $data = $request->validate(['status' => ['required', 'in:active,inactive']]);
        $customer->update(['status' => $data['status']]);

        return $this->ok(['id' => $customer->id, 'status' => $customer->status], 'Status updated.');
    }
}
