<?php

namespace App\Services;

use App\Models\Customer;
use App\Models\Product;
use App\Models\Rental;
use App\Models\RentalInvoice;
use App\Jobs\SendRentalInvoiceWhatsApp;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class RentalService
{
    public function __construct(
        private readonly InventoryService $inventory,
        private readonly SettingsService $settings,
        private readonly ActivityLogService $activity,
    ) {}

    public function list(int|string|null $companyId, array $filters): LengthAwarePaginator
    {
        return Rental::query()
            ->when($companyId !== null, fn ($q) => $q->forCompany($companyId))
            ->with('customer:id,name')
            ->withCount('items')
            ->when(filled($filters['status'] ?? null), fn ($q) => $q->where('status', $filters['status']))
            ->listFilters($filters, 'start_date', ['rental_no'], ['customer' => 'name'])
            ->orderByDesc('start_date')->orderByDesc('created_at')
            ->paginate(min((int) ($filters['per_page'] ?? 15), 100))
            ->withQueryString();
    }

    public function find(int|string $companyId, string $id): ?Rental
    {
        return Rental::forCompany($companyId)
            ->with(['items', 'invoices' => fn ($q) => $q->orderByDesc('period_from'), 'customer:id,name,type'])
            ->whereKey($id)->first();
    }

    public function create(int|string $companyId, array $data, ?int $userId = null): Rental
    {
        $names = Product::forCompany($companyId)
            ->whereIn('id', collect($data['items'])->pluck('product_id')->filter())
            ->get(['id', 'name', 'rental_daily_rate'])
            ->keyBy('id');
        $cycleDays = ['daily' => 1, 'weekly' => 7, 'monthly' => 30][$data['billing_cycle'] ?? 'monthly'] ?? 30;

        return DB::transaction(function () use ($companyId, $data, $names, $cycleDays, $userId) {
            $rental = Rental::create([
                'company_id'        => $companyId,
                'customer_id'       => $data['customer_id'],
                'location_id'       => $data['location_id'] ?? null,
                'rental_no'         => $this->nextRentalNo($companyId),
                'start_date'        => $data['start_date'],
                'expected_end_date' => $data['expected_end_date'] ?? null,
                'billing_cycle'     => $data['billing_cycle'] ?? 'monthly',
                'auto_bill'         => array_key_exists('auto_bill', $data) ? (bool) $data['auto_bill'] : true,
                'deposit'           => $data['deposit'] ?? 0,
                'status'            => 'draft',
                'notes'             => $data['notes'] ?? null,
            ]);

            $rental->items()->createMany(collect($data['items'])->map(function ($i) use ($names, $cycleDays) {
                $product = $names[$i['product_id']] ?? null;
                $rate = isset($i['rate_per_cycle']) ? (float) $i['rate_per_cycle'] : 0;
                if ($rate <= 0 && $product && (float) $product->rental_daily_rate > 0) {
                    $rate = (float) $product->rental_daily_rate * $cycleDays;
                }

                return [
                    'product_id'     => $i['product_id'],
                    'product_name'   => $product?->name ?? 'Item',
                    'qty'            => $i['qty'],
                    'rate_per_cycle' => $rate,
                    'returned_qty'   => 0,
                ];
            })->all());

            $this->logEvent($companyId, $userId, 'create', $rental, 'Rental draft created');

            return $rental->load(['items', 'customer:id,name,type']);
        });
    }

    /** Activate: rented stock leaves inventory. */
    public function activate(Rental $rental, ?int $userId = null): Rental
    {
        if (! $rental->isDraft()) {
            throw ValidationException::withMessages(['status' => 'Only draft rentals can be activated.']);
        }

        return DB::transaction(function () use ($rental, $userId) {
            $rental->loadMissing('items');

            // Security deposit defaults to the full value of the rented goods.
            if ((float) $rental->deposit <= 0) {
                $prices = Product::forCompany($rental->company_id)
                    ->whereIn('id', $rental->items->pluck('product_id')->filter())
                    ->pluck('retail_price', 'id');
                $deposit = $rental->items->sum(fn ($i) => (float) $i->qty * (float) ($prices[$i->product_id] ?? 0));
                if ($deposit > 0) {
                    $rental->deposit = round($deposit, 2);
                }
            }

            foreach ($rental->items as $item) {
                if (! $item->product_id) {
                    continue;
                }
                $product = Product::forCompany($rental->company_id)->lockForUpdate()->find($item->product_id);
                if (! $product) {
                    continue;
                }
                if ((float) $product->current_stock < (float) $item->qty) {
                    throw ValidationException::withMessages([
                        'items' => "Not enough {$product->name}: {$product->current_stock} available, {$item->qty} required.",
                    ]);
                }
                $this->inventory->post(
                    product: $product, direction: 'out', qty: (float) $item->qty,
                    unitCost: (float) $product->cost_price, referenceType: 'rental',
                    referenceId: $rental->id, note: "Rental {$rental->rental_no}", userId: $userId,
                );
                $product->save();
                // Rented plants leave their batches oldest first.
                $this->inventory->consumeBatchesFifo($product->id, (float) $item->qty);
            }

            $rental->update([
                'status'       => 'active',
                'activated_at' => now(),
                'deposit'      => $rental->deposit,
                'next_bill_at' => $this->computeNextBillAt($rental, Carbon::parse($rental->start_date)),
            ]);

            $this->logEvent($rental->company_id, $userId, 'activate', $rental->fresh(), 'Rental activated — stock issued');

            return $rental->refresh()->load(['items', 'customer:id,name,type']);
        });
    }

    /**
     * Final return + settlement. Per line: good units come back to stock;
     * damaged/missing units do not. Charges = rental (day-based) + damage +
     * missing (at product value) are deducted from the deposit; the balance is
     * refunded to the customer, or billed if charges exceed the deposit.
     */
    public function settle(Rental $rental, array $lines, ?string $returnDate = null, ?float $damageCharge = null, ?int $userId = null): Rental
    {
        if (! $rental->isActive()) {
            throw ValidationException::withMessages(['status' => 'Only active rentals can be settled.']);
        }

        $return = $returnDate ? Carbon::parse($returnDate) : Carbon::today();

        return DB::transaction(function () use ($rental, $lines, $return, $damageCharge, $userId) {
            $rental->loadMissing('items');
            $prices = Product::forCompany($rental->company_id)
                ->whereIn('id', $rental->items->pluck('product_id')->filter())
                ->pluck('retail_price', 'id');

            $missingCharge = 0.0;
            $autoDamage = 0.0;

            foreach ($rental->items as $item) {
                $line = $lines[$item->id] ?? [];
                $outstanding = max(0.0, (float) $item->qty - (float) $item->returned_qty - (float) $item->damaged_qty - (float) $item->missing_qty);
                if ($outstanding <= 0) {
                    continue;
                }

                $good = max(0.0, min((float) ($line['returned'] ?? 0), $outstanding));
                $damaged = max(0.0, min((float) ($line['damaged'] ?? 0), $outstanding - $good));
                // Anything not marked good or damaged is missing — settle closes the rental.
                $missing = $outstanding - $good - $damaged;

                // Only good units return to available stock. Damaged units are
                // written off; missing units are sold (stock stays reduced).
                if ($good > 0 && $item->product_id) {
                    $product = Product::forCompany($rental->company_id)->lockForUpdate()->find($item->product_id);
                    if ($product) {
                        $this->inventory->post(
                            product: $product, direction: 'in', qty: $good,
                            unitCost: (float) $product->cost_price, referenceType: 'rental-return',
                            referenceId: $rental->id, note: "Return {$rental->rental_no}", userId: $userId,
                        );
                        $product->save();
                        $this->inventory->restoreBatchesFifo($product->id, $good); // back onto the batches it left
                    }
                }

                $retail = (float) ($prices[$item->product_id] ?? 0);
                $missingCharge += $missing * $retail;
                $autoDamage += $damaged * $retail * 0.5;

                $item->update([
                    'returned_qty' => (float) $item->returned_qty + $good,
                    'damaged_qty'  => (float) $item->damaged_qty + $damaged,
                    'missing_qty'  => (float) $item->missing_qty + $missing,
                ]);
            }

            // Rental charge for the whole period (start → return date).
            $from = Carbon::parse($rental->start_date);
            $days = max(1, $from->diffInDays($return) + 1);
            $cycleDays = ['daily' => 1, 'weekly' => 7, 'monthly' => 30][$rental->billing_cycle] ?? 30;
            $cycles = max(1, (int) ceil($days / $cycleDays));
            $rentalCharge = round($rental->items->sum(fn ($i) => (float) $i->qty * (float) $i->rate_per_cycle * $cycles), 2);

            // Rent already invoiced by the billing cycle (and already added to
            // the customer's outstanding) must not be charged again here.
            $alreadyBilled = round((float) RentalInvoice::query()
                ->where('rental_id', $rental->id)
                ->sum('amount'), 2);
            $rentStillDue = round(max(0, $rentalCharge - $alreadyBilled), 2);

            $damage = $damageCharge === null
                ? round($autoDamage, 2)
                : round((float) $damageCharge, 2);
            $missingCharge = round($missingCharge, 2);
            $totalCharges = round($rentStillDue + $damage + $missingCharge, 2);
            $deposit = (float) $rental->deposit;
            $refund = round(max(0, $deposit - $totalCharges), 2);
            $balanceDue = round(max(0, $totalCharges - $deposit), 2);

            $rental->update([
                'status'         => 'returned',
                'return_date'    => $return->toDateString(),
                'returned_at'    => now(),
                'settled_at'     => now(),
                'rental_charge'  => $rentalCharge,
                'damage_charge'  => $damage,
                'missing_charge' => $missingCharge,
                'refund_amount'  => $refund,
                'balance_due'    => $balanceDue,
            ]);

            // Convert to the final rental invoice capturing all charges.
            RentalInvoice::create([
                'company_id'  => $rental->company_id,
                'rental_id'   => $rental->id,
                'invoice_no'  => $this->nextInvoiceNo($rental->company_id),
                'period_from' => $from->toDateString(),
                'period_to'   => $return->toDateString(),
                'cycles'      => $cycles,
                'amount'      => $totalCharges,
                'status'      => $balanceDue > 0 ? 'unpaid' : 'paid',
                'notes'       => "Rental {$rentalCharge} (already billed {$alreadyBilled}, now {$rentStillDue}), damage {$damage}, missing {$missingCharge}; deposit {$deposit}, refund {$refund}.",
            ]);

            // Only the shortfall beyond the deposit is owed by the customer.
            if ($balanceDue > 0) {
                $this->adjustCustomerOutstanding($rental->company_id, $rental->customer_id, $balanceDue);
            }

            $this->logEvent($rental->company_id, $userId, 'settle', $rental->fresh(), 'Rental settled', [
                'rental_charge' => $rentalCharge,
                'refund_amount' => $refund,
                'balance_due'   => $balanceDue,
            ]);

            return $rental->refresh()->load(['items', 'invoices', 'customer:id,name,type']);
        });
    }

    /** Return some or all rented units; stock comes back. Closes when everything is back. */
    public function returnItems(Rental $rental, array $returns, ?int $userId = null): Rental
    {
        if (! $rental->isActive()) {
            throw ValidationException::withMessages(['status' => 'Only active rentals can be returned.']);
        }

        return DB::transaction(function () use ($rental, $returns, $userId) {
            $rental->loadMissing('items');

            foreach ($rental->items as $item) {
                if (! $item->product_id) {
                    continue;
                }
                $outstanding = (float) $item->qty - (float) $item->returned_qty;
                $requested = array_key_exists($item->id, $returns) ? (float) $returns[$item->id] : 0.0;
                $back = max(0.0, min($requested, $outstanding));
                if ($back <= 0) {
                    continue;
                }
                $product = Product::forCompany($rental->company_id)->lockForUpdate()->find($item->product_id);
                if ($product) {
                    $this->inventory->post(
                        product: $product, direction: 'in', qty: $back,
                        unitCost: (float) $product->cost_price, referenceType: 'rental-return',
                        referenceId: $rental->id, note: "Return {$rental->rental_no}", userId: $userId,
                    );
                    $product->save();
                    $this->inventory->restoreBatchesFifo($product->id, $back); // back onto the batches it left
                }
                $item->update(['returned_qty' => (float) $item->returned_qty + $back]);
            }

            $allBack = $rental->items->every(fn ($i) => (float) $i->returned_qty >= (float) $i->qty);
            if ($allBack) {
                $rental->update(['status' => 'returned', 'returned_at' => now()]);
            }

            return $rental->refresh()->load(['items', 'invoices', 'customer:id,name,type']);
        });
    }

    public function cancel(Rental $rental, ?int $userId = null): Rental
    {
        return DB::transaction(function () use ($rental, $userId) {
            if ($rental->isActive()) {
                $rental->loadMissing('items');
                foreach ($rental->items as $item) {
                    $outstanding = (float) $item->qty - (float) $item->returned_qty;
                    if ($outstanding <= 0 || ! $item->product_id) {
                        continue;
                    }
                    $product = Product::forCompany($rental->company_id)->lockForUpdate()->find($item->product_id);
                    if ($product) {
                        $this->inventory->post(
                            product: $product, direction: 'in', qty: $outstanding,
                            unitCost: (float) $product->cost_price, referenceType: 'rental-cancel',
                            referenceId: $rental->id, note: "Cancel {$rental->rental_no}", userId: $userId,
                        );
                        $product->save();
                    }
                    $item->update(['returned_qty' => (float) $item->qty]);
                }
            }
            $rental->update(['status' => 'cancelled']);

            $this->logEvent($rental->company_id, $userId, 'cancel', $rental->fresh(), 'Rental cancelled');

            return $rental->refresh();
        });
    }

    // ---- Billing ----

    public function generateInvoice(int|string $companyId, Rental $rental, array $data, ?int $userId = null, bool $queueWhatsApp = false): RentalInvoice
    {
        $from = Carbon::parse($data['period_from']);
        $to = Carbon::parse($data['period_to']);
        if ($to->lt($from)) {
            throw ValidationException::withMessages(['period_to' => 'End of period must be on or after the start.']);
        }

        if ($this->invoicePeriodExists($rental, $from, $to)) {
            throw ValidationException::withMessages(['period_from' => 'An invoice already exists for this billing period.']);
        }

        $days = $from->diffInDays($to) + 1;
        $cycleDays = $this->cycleDays($rental->billing_cycle);
        $cycles = max(1, (int) ceil($days / $cycleDays));

        $rental->loadMissing('items');
        $amount = round($rental->items->sum(function ($i) use ($cycles) {
            $activeQty = max(0.0, (float) $i->qty - (float) $i->returned_qty - (float) $i->damaged_qty - (float) $i->missing_qty);

            return $activeQty * (float) $i->rate_per_cycle * $cycles;
        }), 2);

        if ($amount <= 0) {
            throw ValidationException::withMessages([
                'period_from' => 'No plants are still out to bill for this period.',
            ]);
        }

        $dueDays = max(0, $this->settings->getInt($companyId, 'rental_payment_due_days'));

        return DB::transaction(function () use ($companyId, $rental, $from, $to, $cycles, $amount, $dueDays, $queueWhatsApp, $userId) {
            $invoice = RentalInvoice::create([
                'company_id'  => $companyId,
                'rental_id'   => $rental->id,
                'invoice_no'  => $this->nextInvoiceNo($companyId),
                'period_from' => $from->toDateString(),
                'period_to'   => $to->toDateString(),
                'cycles'      => $cycles,
                'amount'      => $amount,
                'due_date'    => $to->copy()->addDays($dueDays)->toDateString(),
                'status'      => 'unpaid',
            ]);

            $this->adjustCustomerOutstanding($rental->company_id, $rental->customer_id, $amount);
            $this->syncBillingSchedule($rental, $to);

            if ($queueWhatsApp && $this->settings->get($companyId, 'rental_whatsapp_on_bill') === '1') {
                SendRentalInvoiceWhatsApp::dispatch($invoice->id);
            }

            $this->logEvent($companyId, $userId, 'invoice', $rental, "Invoice {$invoice->invoice_no} generated", [
                'invoice_id' => $invoice->id,
                'amount'     => $amount,
                'auto'       => $queueWhatsApp,
            ]);

            return $invoice;
        });
    }

    /** @return array{billed: int, skipped: int, errors: list<string>} */
    public function billDueRentals(int|string|null $companyId = null): array
    {
        $result = ['billed' => 0, 'skipped' => 0, 'errors' => []];

        $query = Rental::query()->where('status', 'active')->where('auto_bill', true);
        if ($companyId !== null) {
            $query->forCompany($companyId);
        }

        foreach ($query->with('items')->get() as $rental) {
            if ($this->settings->get($rental->company_id, 'rental_auto_bill') !== '1') {
                $result['skipped']++;

                continue;
            }

            $period = $this->computeBillingPeriod($rental);
            if (! $period) {
                $result['skipped']++;

                continue;
            }

            try {
                $this->generateInvoice($rental->company_id, $rental, $period, null, queueWhatsApp: true);
                $result['billed']++;
            } catch (ValidationException $e) {
                $result['errors'][] = "{$rental->rental_no}: ".collect($e->errors())->flatten()->first();
                $result['skipped']++;
            }
        }

        return $result;
    }

    public function cycleDays(string $billingCycle): int
    {
        return ['daily' => 1, 'weekly' => 7, 'monthly' => 30][$billingCycle] ?? 30;
    }

    /** @return array{period_from: string, period_to: string}|null */
    public function computeBillingPeriod(Rental $rental): ?array
    {
        if (! $rental->isActive()) {
            return null;
        }

        $cycleDays = $this->cycleDays($rental->billing_cycle);
        $periodFrom = $rental->last_billed_to
            ? Carbon::parse($rental->last_billed_to)->addDay()
            : Carbon::parse($rental->start_date);

        if ($periodFrom->gt(Carbon::today())) {
            return null;
        }

        $periodTo = $periodFrom->copy()->addDays($cycleDays - 1);
        if ($periodTo->gt(Carbon::today())) {
            return null;
        }

        if ($this->invoicePeriodExists($rental, $periodFrom, $periodTo)) {
            return null;
        }

        return [
            'period_from' => $periodFrom->toDateString(),
            'period_to'   => $periodTo->toDateString(),
        ];
    }

    private function computeNextBillAt(Rental $rental, Carbon $periodFrom): string
    {
        $cycleDays = $this->cycleDays($rental->billing_cycle);

        return $periodFrom->copy()->addDays($cycleDays - 1)->toDateString();
    }

    private function syncBillingSchedule(Rental $rental, Carbon $periodTo): void
    {
        $nextBillAt = $this->computeNextBillAt($rental, $periodTo->copy()->addDay());
        $rental->update([
            'last_billed_to' => $periodTo->toDateString(),
            'next_bill_at'   => $nextBillAt,
        ]);
    }

    private function invoicePeriodExists(Rental $rental, Carbon $from, Carbon $to): bool
    {
        return $rental->invoices()
            ->whereDate('period_from', '<=', $to)
            ->whereDate('period_to', '>=', $from)
            ->exists();
    }

    public function markInvoicePaid(RentalInvoice $invoice): RentalInvoice
    {
        if ($invoice->status !== 'paid') {
            DB::transaction(function () use ($invoice) {
                $invoice->update(['status' => 'paid']);
                $rental = $invoice->rental()->first();
                if ($rental) {
                    $this->adjustCustomerOutstanding($invoice->company_id, $rental->customer_id, -(float) $invoice->amount);
                }
            });
        }

        return $invoice->refresh();
    }

    public function deleteInvoice(RentalInvoice $invoice): void
    {
        DB::transaction(function () use ($invoice) {
            // Only an unpaid invoice still sits on the customer's outstanding.
            if ($invoice->status === 'unpaid') {
                $rental = $invoice->rental()->first();
                if ($rental) {
                    $this->adjustCustomerOutstanding($invoice->company_id, $rental->customer_id, -(float) $invoice->amount);
                }
            }
            $invoice->delete();
        });
    }

    private function adjustCustomerOutstanding(int|string $companyId, string $customerId, float $delta): void
    {
        $customer = Customer::forCompany($companyId)->lockForUpdate()->find($customerId);
        if ($customer) {
            $customer->outstanding = (float) $customer->outstanding + $delta;
            $customer->save();
        }
    }

    private function logEvent(int|string $companyId, ?int $userId, string $action, Rental $rental, string $description, ?array $meta = null): void
    {
        $this->activity->log(
            $companyId,
            $userId,
            $action,
            'rental',
            'rental',
            $rental->id,
            $description,
            array_merge(['rental_no' => $rental->rental_no], $meta ?? []),
        );
    }

    private function nextRentalNo(int|string $companyId): string
    {
        return \App\Support\Numbering\DocumentNumber::next(Rental::query()->where('company_id', $companyId), 'rental_no', 'RNT-', 6);
    }

    private function nextInvoiceNo(int|string $companyId): string
    {
        $count = RentalInvoice::forCompany($companyId)->count();

        return 'RINV-'.str_pad((string) ($count + 1), 6, '0', STR_PAD_LEFT);
    }
}
