<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\SettingsService;
use App\Support\Api\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    use ApiResponse;

    public function __construct(private readonly SettingsService $settings) {}

    public function show(Request $request): JsonResponse
    {
        $company = $request->attributes->get('company');
        abort_unless($request->user()->hasPermission('settings.view', $company->id)
            || $request->user()->hasPermission('*', $company->id)
            || $request->user()->is_super_admin, 403);

        return $this->ok($this->settings->all($company->id));
    }

    public function update(Request $request): JsonResponse
    {
        $company = $request->attributes->get('company');
        abort_unless($request->user()->hasPermission('settings.update', $company->id)
            || $request->user()->hasPermission('*', $company->id)
            || $request->user()->is_super_admin, 403);

        $data = $request->validate([
            'loyalty_earn_rupees'        => ['sometimes', 'numeric', 'min:1'],
            'loyalty_earn_points'        => ['sometimes', 'integer', 'min:1'],
            'loyalty_redeem_rupees'      => ['sometimes', 'numeric', 'min:0.01'],
            'loyalty_redeem_cap_percent' => ['sometimes', 'numeric', 'min:0', 'max:100'],
            'loyalty_redeem_min_points'  => ['sometimes', 'integer', 'min:0'],
            'loyalty_points_expiry_days' => ['sometimes', 'integer', 'min:0', 'max:3650'],
            'discount_ceiling_percent'   => ['sometimes', 'numeric', 'min:0', 'max:100'],
            'landed_cost_payable_to_supplier' => ['sometimes', 'in:0,1,true,false'],
            'reorder_alert_default'      => ['sometimes', 'numeric', 'min:0'],
            'website_integration'        => ['sometimes', 'in:0,1,true,false'],
            'whatsapp_enabled'           => ['sometimes', 'in:0,1,true,false'],
            'rental_auto_bill'           => ['sometimes', 'in:0,1,true,false'],
            'rental_whatsapp_on_bill'    => ['sometimes', 'in:0,1,true,false'],
            'rental_payment_due_days'    => ['sometimes', 'integer', 'min:0', 'max:90'],
            'rental_overdue_alert_days'  => ['sometimes', 'integer', 'min:0', 'max:90'],
            'rental_reminder_lead_days'  => ['sometimes', 'integer', 'min:0', 'max:90'],
            'sms_enabled'                => ['sometimes', 'in:0,1,true,false'],
            'sale_cancel_requires_approval' => ['sometimes', 'in:0,1,true,false'],
            'cash_opening_balance'         => ['sometimes', 'numeric', 'min:0'],
            'bank_opening_balance'         => ['sometimes', 'numeric', 'min:0'],
            'financial_year_start_month'   => ['sometimes', 'integer', 'min:1', 'max:12'],
            'dead_stock_days'              => ['sometimes', 'integer', 'min:30', 'max:730'],
            'eod_management_enabled'       => ['sometimes', 'in:0,1,true,false'],
            'eod_management_whatsapp_phones' => ['sometimes', 'string', 'max:2000'],
            'eod_management_email_recipients' => ['sometimes', 'string', 'max:2000'],
            'eod_management_send_time'       => ['sometimes', 'date_format:H:i'],
            'eod_commission_send_time'       => ['sometimes', 'date_format:H:i'],
            'company_timezone'               => ['sometimes', 'timezone'],
            'seasonal_care_rate_limit'       => ['sometimes', 'integer', 'min:1', 'max:500'],
            'daily_expense'              => ['sometimes', 'numeric', 'min:0'],
        ]);

        foreach (['website_integration', 'whatsapp_enabled', 'sms_enabled', 'rental_auto_bill', 'rental_whatsapp_on_bill', 'sale_cancel_requires_approval', 'eod_management_enabled', 'landed_cost_payable_to_supplier'] as $flag) {
            if (isset($data[$flag])) {
                $data[$flag] = in_array($data[$flag], [true, 'true', '1', 1], true) ? '1' : '0';
            }
        }

        return $this->ok($this->settings->setMany($company->id, $data), 'Settings saved.');
    }
}
