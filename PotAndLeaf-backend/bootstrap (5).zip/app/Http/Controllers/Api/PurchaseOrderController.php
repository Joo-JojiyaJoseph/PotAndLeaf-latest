<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\PurchaseOrder\BatchPurchaseOrderRequest;
use App\Http\Requests\PurchaseOrder\StorePurchaseOrderRequest;
use App\Http\Resources\PurchaseOrderResource;
use App\Models\Company;
use App\Models\Product;
use App\Models\PurchaseOrder;
use App\Models\Supplier;
use App\Services\PurchaseOrderService;
use App\Support\Api\ApiResponse;
use App\Support\Api\AssertsRecordCompany;
use App\Support\Api\ResolvesFilterCompany;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class PurchaseOrderController extends Controller
{
    use ApiResponse, AssertsRecordCompany, ResolvesFilterCompany;

    public function __construct(private readonly PurchaseOrderService $orders) {}

    public function index(Request $request): JsonResponse
    {
        $this->allow($request, 'po.view');

        return $this->ok(PurchaseOrderResource::collection($this->orders->list($this->listCompanyId($request), $request->only(['search', 'status', 'per_page', 'from', 'to']))));
    }

    public function formData(Request $request): JsonResponse
    {
        $company = $this->company($request);
        $this->allow($request, 'po.create');

        $suppliers = Supplier::forCompany($company->id)->where('status', 'active')->orderBy('name')->get(['id', 'name'])
            ->map(fn ($s) => ['id' => $s->id, 'name' => $s->name]);
        $products = Product::forCompany($company->id)->where('status', 'active')->orderBy('name')
            ->get(['id', 'sku', 'name', 'cost_price', 'gst_rate', 'length_cm', 'width_cm', 'height_cm'])
            ->map(fn ($p) => [
                'id' => $p->id, 'sku' => $p->sku, 'name' => $p->name, 'cost_price' => (float) $p->cost_price, 'gst_rate' => (float) $p->gst_rate,
                // Dimensions for CBM (container planning on import orders).
                'length_cm' => (float) $p->length_cm, 'width_cm' => (float) $p->width_cm, 'height_cm' => (float) $p->height_cm,
            ]);

        return $this->ok(['suppliers' => $suppliers, 'products' => $products]);
    }

    public function suggestions(Request $request): JsonResponse
    {
        $company = $this->company($request);
        $this->allow($request, 'po.view');

        return $this->ok(['suggestions' => $this->orders->reorderSuggestions($company->id)]);
    }

    public function reorderReport(Request $request): JsonResponse
    {
        $this->allow($request, 'po.view');
        $companyId = $this->listCompanyId($request) ?? $this->company($request)->id;

        return $this->ok($this->orders->reorderReport($companyId));
    }

    public function exportReorder(Request $request): Response
    {
        $this->allow($request, 'po.view');
        $headerCompany = $this->company($request);
        $companyId = $this->listCompanyId($request) ?? $headerCompany->id;
        $company = (string) $companyId === (string) $headerCompany->id
            ? $headerCompany
            : (Company::find($companyId) ?? $headerCompany);
        $layout = $request->query('layout') === 'flat' ? 'flat' : 'supplier';
        // The screen sends what was picked there (supplier, qty, ticked) so the PDF matches it.
        $choices = json_decode((string) $request->query('choices', ''), true);
        $report = $this->orders->reorderReport($company->id, is_array($choices) ? $choices : []);

        $pdf = Pdf::loadView('pdf.reorder-report', [
            'company'      => $company,
            'report'       => $report,
            'layout'       => $layout,
            'generated_at' => now()->toDateTimeString(),
            'generated_by' => $request->user()?->name,
        ])->setPaper('a4', $layout === 'flat' ? 'landscape' : 'portrait');

        $filename = $layout === 'supplier' ? 'reorder-report-supplier.pdf' : 'reorder-report.pdf';

        return $pdf->download($filename);
    }

    public function batchFromReorder(BatchPurchaseOrderRequest $request): JsonResponse
    {
        $company = $this->company($request);
        $orders = $this->orders->createBatchFromReorder($company->id, $request->validated(), $request->user()->id);

        return $this->created(
            PurchaseOrderResource::collection(collect($orders)),
            count($orders).' purchase order(s) created from reorder report.',
        );
    }

    public function store(StorePurchaseOrderRequest $request): JsonResponse
    {
        $company = $this->company($request);
        $po = $this->orders->create($company->id, $request->validated(), $request->user()->id);

        return $this->created(new PurchaseOrderResource($po), 'Purchase order created.');
    }

    public function show(Request $request, PurchaseOrder $purchaseOrder): JsonResponse
    {
        $this->allow($request, 'po.view');
        $this->assertRecordCompany($request, $purchaseOrder);

        return $this->ok(new PurchaseOrderResource($purchaseOrder->load([
            'items.product:id,sku,name',
            'supplier',
            'createdBy:id,name',
        ])));
    }

    public function send(Request $request, PurchaseOrder $purchaseOrder): JsonResponse
    {
        $this->allow($request, 'po.send');
        $this->assertRecordCompany($request, $purchaseOrder, writable: true);

        return $this->ok(new PurchaseOrderResource($this->orders->send($purchaseOrder)), 'PO marked as sent.');
    }

    public function convert(Request $request, PurchaseOrder $purchaseOrder): JsonResponse
    {
        $this->allow($request, 'po.convert');
        $this->assertRecordCompany($request, $purchaseOrder, writable: true);
        $result = $this->orders->convertToPurchase($purchaseOrder, $request->user()->id);

        return $this->ok(['purchase_id' => $result['purchase_id']], 'Draft GRN created from PO.');
    }

    public function destroy(Request $request, PurchaseOrder $purchaseOrder): JsonResponse
    {
        $this->allow($request, 'po.delete');
        $this->assertRecordCompany($request, $purchaseOrder, writable: true);
        $this->orders->cancel($purchaseOrder);

        return $this->message('Purchase order cancelled.');
    }

    private function company(Request $request)
    {
        return $request->attributes->get('company');
    }

    private function allow(Request $request, string $permission): void
    {
        abort_unless($request->user()->hasPermission($permission, $this->company($request)->id), 403);
    }

}
