<?php

namespace App\Http\Resources;

use App\Http\Resources\Concerns\ResolvesMediaUrls;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin Supplier */
class SupplierResource extends JsonResource
{
    use ResolvesMediaUrls;
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        $user = $request->user();
        $companyId = $this->company_id;

        return [
            'id'                => $this->id,
            'company_id'        => $companyId,
            'supplier_code'     => $this->supplier_code,
            'name'              => $this->name,
            'photo'             => $this->mediaUrl($this->photo),
            'email'             => $this->email,
            'phone'             => $this->phone,
            'gst_number'        => $this->gst_number,
            'pan_number'        => $this->pan_number,
            'address'           => $this->address,
            'address_line1'     => $this->address_line1,
            'address_line2'     => $this->address_line2,
            'city'              => $this->city,
            'state'             => $this->state,
            'country'           => $this->country,
            'pincode'           => $this->pincode,
            'bank_name'         => $this->bank_name,
            'bank_account_name' => $this->bank_account_name,
            'bank_account_no'   => $this->bank_account_no,
            'bank_ifsc'         => $this->bank_ifsc,
            'credit_limit'    => (float) $this->credit_limit,
            'credit_days'     => (int) $this->credit_days,
            'opening_balance' => (float) $this->opening_balance,
            'outstanding'     => (float) $this->outstanding,
            'advance_balance' => (float) $this->advance_balance,
            'notes'           => $this->notes,
            'status'          => $this->status,
            'created_at'      => $this->created_at?->toIso8601String(),
            'updated_at'      => $this->updated_at?->toIso8601String(),
            'can'             => [
                'update' => $user?->hasPermission('suppliers.update', $companyId),
                'delete' => $user?->hasPermission('suppliers.delete', $companyId),
            ],
        ];
    }
}
