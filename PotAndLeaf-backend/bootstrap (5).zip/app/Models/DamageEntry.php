<?php

namespace App\Models;

use App\Models\Concerns\HasAuditColumns;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DamageEntry extends Model
{
    use HasAuditColumns, HasFactory, HasUuids;

    protected $fillable = [
        'company_id', 'product_id', 'product_batch_id', 'location_id', 'entry_no', 'entry_date',
        'qty', 'returned_qty', 'reason', 'notes', 'photo',
    ];

    protected function casts(): array
    {
        return [
            'entry_date'   => 'date',
            'qty'          => 'decimal:3',
            'returned_qty' => 'decimal:3',
        ];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function batch(): BelongsTo
    {
        return $this->belongsTo(ProductBatch::class, 'product_batch_id');
    }

    public function eligibleReturnQty(): float
    {
        return max(0, round((float) $this->qty - (float) $this->returned_qty, 3));
    }

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class);
    }

    public function scopeForCompany($query, int|string $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
